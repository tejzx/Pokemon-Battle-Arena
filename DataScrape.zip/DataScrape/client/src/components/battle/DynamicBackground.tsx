import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useTexture } from '@react-three/drei';
import * as THREE from 'three';

interface DynamicBackgroundProps {
  environment: 'grass' | 'water' | 'fire' | 'electric' | 'psychic' | 'cave';
  weather?: 'sunny' | 'rain' | 'storm';
}

export function DynamicBackground({ environment, weather = 'sunny' }: DynamicBackgroundProps) {
  const skyRef = useRef<THREE.Mesh>(null);
  const particlesRef = useRef<THREE.Points>(null);
  
  // Load different textures based on environment
  const backgroundTexture = useTexture(
    environment === 'water' ? '/textures/water.png' :
    environment === 'fire' ? '/textures/lava.png' :
    '/textures/grass.png'
  );

  // Create particle system for environmental effects
  const particleSystem = useMemo(() => {
    const particleCount = 1000;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount; i++) {
      // Position particles
      positions[i * 3] = (Math.random() - 0.5) * 50;
      positions[i * 3 + 1] = Math.random() * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 50;
      
      // Color particles based on environment
      switch (environment) {
        case 'fire':
          colors[i * 3] = 1; // Red
          colors[i * 3 + 1] = Math.random() * 0.5; // Green
          colors[i * 3 + 2] = 0; // Blue
          break;
        case 'water':
          colors[i * 3] = 0; // Red
          colors[i * 3 + 1] = Math.random() * 0.5; // Green
          colors[i * 3 + 2] = 1; // Blue
          break;
        case 'electric':
          colors[i * 3] = 1; // Red
          colors[i * 3 + 1] = 1; // Green
          colors[i * 3 + 2] = 0; // Blue
          break;
        case 'psychic':
          colors[i * 3] = 1; // Red
          colors[i * 3 + 1] = 0; // Green
          colors[i * 3 + 2] = 1; // Blue
          break;
        default:
          colors[i * 3] = 0.5; // Red
          colors[i * 3 + 1] = 1; // Green
          colors[i * 3 + 2] = 0.5; // Blue
      }
    }
    
    return { positions, colors };
  }, [environment]);

  // Animate background elements
  useFrame((state) => {
    if (skyRef.current) {
      // Rotate sky slowly
      skyRef.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
    
    if (particlesRef.current) {
      // Animate particles based on weather
      const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
      
      for (let i = 0; i < positions.length; i += 3) {
        if (weather === 'rain') {
          positions[i + 1] -= 0.1; // Fall down
          if (positions[i + 1] < -5) {
            positions[i + 1] = 20; // Reset to top
          }
        } else if (weather === 'storm') {
          positions[i] += Math.sin(state.clock.elapsedTime * 2 + i) * 0.02;
          positions[i + 1] -= 0.15;
          if (positions[i + 1] < -5) {
            positions[i + 1] = 20;
          }
        } else {
          // Gentle floating for sunny weather
          positions[i + 1] += Math.sin(state.clock.elapsedTime + i * 0.01) * 0.01;
        }
      }
      
      particlesRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <group>
      {/* Sky dome */}
      <mesh ref={skyRef}>
        <sphereGeometry args={[100, 32, 16]} />
        <meshBasicMaterial 
          color={
            environment === 'fire' ? '#ff4444' :
            environment === 'water' ? '#4444ff' :
            environment === 'electric' ? '#ffff44' :
            environment === 'psychic' ? '#ff44ff' :
            environment === 'cave' ? '#222222' :
            '#87ceeb'
          } 
          side={THREE.BackSide}
          transparent
          opacity={0.6}
        />
      </mesh>

      {/* Environmental particles */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={particleSystem.positions.length / 3}
            array={particleSystem.positions}
            itemSize={3}
          />
          <bufferAttribute
            attach="attributes-color"
            count={particleSystem.colors.length / 3}
            array={particleSystem.colors}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial 
          size={0.1} 
          vertexColors 
          transparent 
          opacity={0.6}
          sizeAttenuation={true}
        />
      </points>

      {/* Environment-specific lighting */}
      <ambientLight 
        intensity={
          environment === 'cave' ? 0.3 :
          environment === 'fire' ? 0.8 :
          0.6
        } 
        color={
          environment === 'fire' ? '#ff6666' :
          environment === 'water' ? '#6666ff' :
          environment === 'electric' ? '#ffff66' :
          '#ffffff'
        }
      />
      
      <directionalLight
        position={[10, 10, 5]}
        intensity={environment === 'cave' ? 0.5 : 1}
        color={
          environment === 'fire' ? '#ff8888' :
          environment === 'water' ? '#8888ff' :
          environment === 'electric' ? '#ffff88' :
          '#ffffff'
        }
        castShadow
      />
    </group>
  );
}