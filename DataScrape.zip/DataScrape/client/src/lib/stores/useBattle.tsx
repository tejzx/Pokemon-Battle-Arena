import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";
import { calculateDamage, getEffectiveness } from "../battleLogic";

export type BattlePhase = "selection" | "battle" | "victory";

interface BattleMove {
  name: string;
  type: string;
  power: number;
  accuracy: number;
  pp: number;
}

interface PokemonData {
  id: number;
  name: string;
  types: string[];
  imageUrl: string;
  stats: {
    hp: number;
    attack: number;
    defense: number;
    speed: number;
  };
  moves: BattleMove[];
  currentHp: number;
}

interface BattleState {
  battlePhase: BattlePhase;
  playerPokemon: PokemonData | null;
  enemyPokemon: PokemonData | null;
  currentTurn: 'player' | 'enemy';
  battleLog: string[];
  isAttacking: boolean;
  lastAttack: BattleMove | null;
  playerAttackCount: number;
  playerDefenseCount: number;
  enemyAttackCount: number;
  enemyDefenseCount: number;
  canEndBattle: boolean;

  // Actions
  selectPlayerPokemon: (pokemon: PokemonData) => void;
  selectEnemyPokemon: (pokemon: PokemonData) => void;
  startBattle: () => void;
  executeAttack: (move: BattleMove, isPlayer: boolean) => void;
  switchToEnemyTurn: () => void;
  switchToPlayerTurn: () => void;
  endBattle: (winner: 'player' | 'enemy') => void;
  addToBattleLog: (message: string) => void;
  resetBattle: () => void;
}

export const useBattle = create<BattleState>()(
  subscribeWithSelector((set, get) => ({
    battlePhase: "selection",
    playerPokemon: null,
    enemyPokemon: null,
    currentTurn: 'player',
    battleLog: [],
    isAttacking: false,
    lastAttack: null,
    playerAttackCount: 0,
    playerDefenseCount: 0,
    enemyAttackCount: 0,
    enemyDefenseCount: 0,
    canEndBattle: false,

    selectPlayerPokemon: (pokemon) => {
      set({ 
        playerPokemon: { 
          ...pokemon, 
          currentHp: pokemon.stats.hp 
        } 
      });
    },

    selectEnemyPokemon: (pokemon) => {
      set({ 
        enemyPokemon: { 
          ...pokemon, 
          currentHp: pokemon.stats.hp 
        } 
      });
    },

    startBattle: () => {
      const { playerPokemon, enemyPokemon } = get();
      console.log('startBattle called with:', { playerPokemon, enemyPokemon });
      if (playerPokemon && enemyPokemon) {
        // Determine who goes first based on speed
        const firstTurn = playerPokemon.stats.speed >= enemyPokemon.stats.speed ? 'player' : 'enemy';
        console.log('Setting battle phase to battle, first turn:', firstTurn);
        set({ 
          battlePhase: "battle", 
          currentTurn: firstTurn,
          battleLog: [`${playerPokemon.name} vs ${enemyPokemon.name}!`, `Battle begins!`]
        });
      } else {
        console.error('Cannot start battle: missing Pokemon', { playerPokemon, enemyPokemon });
      }
    },

    executeAttack: (move, isPlayer) => {
      const state = get();
      const { playerPokemon, enemyPokemon, playerAttackCount, playerDefenseCount, enemyAttackCount, enemyDefenseCount } = state;
      
      if (!playerPokemon || !enemyPokemon) return;

      const attacker = isPlayer ? playerPokemon : enemyPokemon;
      const defender = isPlayer ? enemyPokemon : playerPokemon;

      set({ isAttacking: true, lastAttack: move });

      // Track move counts for minimum battle requirement
      const isAttackMove = move.power > 0;
      const updatedState: any = {};
      
      if (isPlayer) {
        if (isAttackMove) {
          updatedState.playerAttackCount = playerAttackCount + 1;
        } else {
          updatedState.playerDefenseCount = playerDefenseCount + 1;
        }
      } else {
        if (isAttackMove) {
          updatedState.enemyAttackCount = enemyAttackCount + 1;
        } else {
          updatedState.enemyDefenseCount = enemyDefenseCount + 1;
        }
      }
      
      // Check if minimum move requirements are met (5 attack + 5 defense each)
      const newPlayerAttack = updatedState.playerAttackCount || playerAttackCount;
      const newPlayerDefense = updatedState.playerDefenseCount || playerDefenseCount;
      const newEnemyAttack = updatedState.enemyAttackCount || enemyAttackCount;
      const newEnemyDefense = updatedState.enemyDefenseCount || enemyDefenseCount;
      
      const canEndBattle = (newPlayerAttack >= 5 && newPlayerDefense >= 5 && 
                           newEnemyAttack >= 5 && newEnemyDefense >= 5);
      updatedState.canEndBattle = canEndBattle;

      // Calculate damage
      const damage = calculateDamage(attacker, defender, move);
      const newHp = Math.max(0, defender.currentHp - damage);

      // Update defender's HP
      if (isPlayer) {
        updatedState.enemyPokemon = { ...enemyPokemon, currentHp: newHp };
      } else {
        updatedState.playerPokemon = { ...playerPokemon, currentHp: newHp };
      }

      set(updatedState);

      // Add to battle log with move count info
      const effectiveness = getEffectiveness(move.type, defender.types);
      let effectMessage = "";
      if (effectiveness > 1) effectMessage = " It's super effective!";
      else if (effectiveness < 1) effectMessage = " It's not very effective...";
      if (damage === 0 && move.power > 0) effectMessage = " The attack missed!";
      else if (move.power === 0) effectMessage = " A tactical move!";

      const moveType = isAttackMove ? "Attack" : "Defense";
      const logMessage = `${attacker.name} used ${move.name} (${moveType})! ${damage > 0 ? damage + ' damage dealt.' : 'No damage.'}${effectMessage}`;
      
      set(state => ({
        battleLog: [...state.battleLog, logMessage]
      }));

      // Check for battle end only if minimum requirements met
      setTimeout(() => {
        const currentState = get();
        if (currentState.canEndBattle) {
          if (currentState.playerPokemon?.currentHp === 0) {
            get().endBattle('enemy');
          } else if (currentState.enemyPokemon?.currentHp === 0) {
            get().endBattle('player');
          }
        } else if (currentState.playerPokemon?.currentHp === 0 || currentState.enemyPokemon?.currentHp === 0) {
          // Heal slightly to continue battle if minimum not met
          const healAmount = 10;
          if (currentState.playerPokemon?.currentHp === 0) {
            set({ playerPokemon: { ...currentState.playerPokemon, currentHp: healAmount } });
            get().addToBattleLog("Player Pokémon refuses to give up! HP restored!");
          }
          if (currentState.enemyPokemon?.currentHp === 0) {
            set({ enemyPokemon: { ...currentState.enemyPokemon, currentHp: healAmount } });
            get().addToBattleLog("Enemy Pokémon shows incredible determination! HP restored!");
          }
        }
        
        set({ isAttacking: false });
      }, 800);
    },

    switchToEnemyTurn: () => {
      set({ currentTurn: 'enemy' });
      
      // AI makes a move after delay
      setTimeout(() => {
        const { enemyPokemon, enemyAttackCount, enemyDefenseCount } = get();
        if (enemyPokemon && enemyPokemon.moves.length > 0) {
          // AI strategy: balance attack and defense moves
          const attackMoves = enemyPokemon.moves.filter(move => move.power > 0);
          const defenseMoves = enemyPokemon.moves.filter(move => move.power === 0);
          
          let selectedMove;
          if (enemyAttackCount < 5 && enemyDefenseCount < 5) {
            // Need both, choose randomly with preference for balance
            if (attackMoves.length > 0 && defenseMoves.length > 0) {
              selectedMove = Math.random() > 0.5 ? 
                attackMoves[Math.floor(Math.random() * attackMoves.length)] :
                defenseMoves[Math.floor(Math.random() * defenseMoves.length)];
            } else {
              selectedMove = enemyPokemon.moves[Math.floor(Math.random() * enemyPokemon.moves.length)];
            }
          } else if (enemyAttackCount < 5) {
            // Need more attack moves
            selectedMove = attackMoves.length > 0 ? 
              attackMoves[Math.floor(Math.random() * attackMoves.length)] :
              enemyPokemon.moves[Math.floor(Math.random() * enemyPokemon.moves.length)];
          } else if (enemyDefenseCount < 5) {
            // Need more defense moves
            selectedMove = defenseMoves.length > 0 ? 
              defenseMoves[Math.floor(Math.random() * defenseMoves.length)] :
              enemyPokemon.moves[Math.floor(Math.random() * enemyPokemon.moves.length)];
          } else {
            // Can use any move now that requirements are met
            selectedMove = enemyPokemon.moves[Math.floor(Math.random() * enemyPokemon.moves.length)];
          }
          
          get().executeAttack(selectedMove, false);
          
          setTimeout(() => {
            get().switchToPlayerTurn();
          }, 2000);
        }
      }, 1500);
    },

    switchToPlayerTurn: () => {
      set({ currentTurn: 'player' });
    },

    endBattle: (winner) => {
      const message = winner === 'player' ? "You won the battle!" : "You lost the battle!";
      set(state => ({
        battlePhase: "victory",
        battleLog: [...state.battleLog, message]
      }));
    },

    addToBattleLog: (message) => {
      set(state => ({
        battleLog: [...state.battleLog, message]
      }));
    },

    resetBattle: () => {
      set({
        battlePhase: "selection",
        playerPokemon: null,
        enemyPokemon: null,
        currentTurn: 'player',
        battleLog: [],
        isAttacking: false,
        lastAttack: null,
        playerAttackCount: 0,
        playerDefenseCount: 0,
        enemyAttackCount: 0,
        enemyDefenseCount: 0,
        canEndBattle: false
      });
    }
  }))
);
