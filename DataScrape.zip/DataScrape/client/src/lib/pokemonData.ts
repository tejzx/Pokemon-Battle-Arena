import { mcpClient } from './mcpClient';

export interface PokemonMove {
  name: string;
  type: string;
  power: number;
  accuracy: number;
  pp: number;
}

export interface Pokemon {
  id: number;
  name: string;
  types: string[];
  stats: {
    hp: number;
    attack: number;
    defense: number;
    speed: number;
  };
  moves: PokemonMove[];
  imageUrl: string;
}

// Comprehensive Pokémon data organized by generations
const fallbackPokemon: Pokemon[] = [
  // Generation 1 - Kanto Starters & Popular
  {
    id: 25,
    name: "Pikachu",
    types: ["electric"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png",
    stats: {
      hp: 35,
      attack: 55,
      defense: 40,
      speed: 90
    },
    moves: [
      { name: "Thunderbolt", type: "electric", power: 70, accuracy: 100, pp: 25 },
      { name: "Quick Attack", type: "normal", power: 30, accuracy: 100, pp: 35 },
      { name: "Iron Tail", type: "steel", power: 65, accuracy: 85, pp: 20 },
      { name: "Thunder Wave", type: "electric", power: 0, accuracy: 90, pp: 30 },
      { name: "Agility", type: "psychic", power: 0, accuracy: 100, pp: 25 },
      { name: "Double Team", type: "normal", power: 0, accuracy: 100, pp: 20 },
      { name: "Thunder", type: "electric", power: 85, accuracy: 70, pp: 15 },
      { name: "Electro Ball", type: "electric", power: 45, accuracy: 100, pp: 25 }
    ]
  },
  {
    id: 4,
    name: "Charmander",
    types: ["fire"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png",
    stats: {
      hp: 39,
      attack: 52,
      defense: 43,
      speed: 65
    },
    moves: [
      { name: "Ember", type: "fire", power: 35, accuracy: 100, pp: 30 },
      { name: "Scratch", type: "normal", power: 30, accuracy: 100, pp: 40 },
      { name: "Growl", type: "normal", power: 0, accuracy: 100, pp: 35 },
      { name: "Smokescreen", type: "normal", power: 0, accuracy: 100, pp: 25 },
      { name: "Dragon Rage", type: "dragon", power: 40, accuracy: 100, pp: 15 },
      { name: "Fire Fang", type: "fire", power: 50, accuracy: 95, pp: 20 },
      { name: "Flamethrower", type: "fire", power: 75, accuracy: 100, pp: 18 },
      { name: "Slash", type: "normal", power: 55, accuracy: 100, pp: 25 }
    ]
  },
  {
    id: 1,
    name: "Bulbasaur",
    types: ["grass", "poison"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png",
    stats: {
      hp: 45,
      attack: 49,
      defense: 49,
      speed: 45
    },
    moves: [
      { name: "Tackle", type: "normal", power: 30, accuracy: 100, pp: 40 },
      { name: "Vine Whip", type: "grass", power: 40, accuracy: 100, pp: 30 },
      { name: "Growl", type: "normal", power: 0, accuracy: 100, pp: 35 },
      { name: "Leech Seed", type: "grass", power: 0, accuracy: 90, pp: 15 },
      { name: "Razor Leaf", type: "grass", power: 50, accuracy: 95, pp: 28 },
      { name: "Sleep Powder", type: "grass", power: 0, accuracy: 75, pp: 20 },
      { name: "Poison Powder", type: "poison", power: 0, accuracy: 75, pp: 20 },
      { name: "Seed Bomb", type: "grass", power: 65, accuracy: 100, pp: 18 }
    ]
  },
  {
    id: 7,
    name: "Squirtle",
    types: ["water"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png",
    stats: {
      hp: 44,
      attack: 48,
      defense: 65,
      speed: 43
    },
    moves: [
      { name: "Tackle", type: "normal", power: 30, accuracy: 100, pp: 40 },
      { name: "Water Gun", type: "water", power: 35, accuracy: 100, pp: 30 },
      { name: "Withdraw", type: "water", power: 0, accuracy: 100, pp: 35 },
      { name: "Bubble", type: "water", power: 40, accuracy: 100, pp: 30 },
      { name: "Water Pulse", type: "water", power: 50, accuracy: 100, pp: 25 },
      { name: "Protect", type: "normal", power: 0, accuracy: 100, pp: 15 },
      { name: "Rain Dance", type: "water", power: 0, accuracy: 100, pp: 20 },
      { name: "Hydro Pump", type: "water", power: 80, accuracy: 85, pp: 15 }
    ]
  },

  {
    id: 150,
    name: "Mewtwo",
    types: ["psychic"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png",
    stats: {
      hp: 106,
      attack: 110,
      defense: 90,
      speed: 130
    },
    moves: [
      { name: "Psychic", type: "psychic", power: 90, accuracy: 100, pp: 10 },
      { name: "Shadow Ball", type: "ghost", power: 80, accuracy: 100, pp: 15 },
      { name: "Aura Sphere", type: "fighting", power: 80, accuracy: 100, pp: 20 },
      { name: "Psystrike", type: "psychic", power: 100, accuracy: 100, pp: 10 }
    ]
  },
  {
    id: 6,
    name: "Charizard",
    types: ["fire", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/6.png",
    stats: {
      hp: 78,
      attack: 84,
      defense: 78,
      speed: 100
    },
    moves: [
      { name: "Fire Blast", type: "fire", power: 110, accuracy: 85, pp: 5 },
      { name: "Air Slash", type: "flying", power: 75, accuracy: 95, pp: 15 },
      { name: "Dragon Claw", type: "dragon", power: 80, accuracy: 100, pp: 15 },
      { name: "Solar Beam", type: "grass", power: 120, accuracy: 100, pp: 10 }
    ]
  },
  {
    id: 9,
    name: "Blastoise",
    types: ["water"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/9.png",
    stats: {
      hp: 79,
      attack: 83,
      defense: 100,
      speed: 78
    },
    moves: [
      { name: "Hydro Pump", type: "water", power: 110, accuracy: 80, pp: 5 },
      { name: "Ice Beam", type: "ice", power: 90, accuracy: 100, pp: 10 },
      { name: "Earthquake", type: "ground", power: 100, accuracy: 100, pp: 10 },
      { name: "Focus Blast", type: "fighting", power: 120, accuracy: 70, pp: 5 }
    ]
  },
  {
    id: 3,
    name: "Venusaur",
    types: ["grass", "poison"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/3.png",
    stats: {
      hp: 80,
      attack: 82,
      defense: 83,
      speed: 80
    },
    moves: [
      { name: "Solar Beam", type: "grass", power: 120, accuracy: 100, pp: 10 },
      { name: "Sludge Bomb", type: "poison", power: 90, accuracy: 100, pp: 10 },
      { name: "Earthquake", type: "ground", power: 100, accuracy: 100, pp: 10 },
      { name: "Sleep Powder", type: "grass", power: 0, accuracy: 75, pp: 15 }
    ]
  },
  {
    id: 144,
    name: "Articuno",
    types: ["ice", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/144.png",
    stats: {
      hp: 90,
      attack: 85,
      defense: 100,
      speed: 85
    },
    moves: [
      { name: "Blizzard", type: "ice", power: 110, accuracy: 70, pp: 5 },
      { name: "Hurricane", type: "flying", power: 110, accuracy: 70, pp: 10 },
      { name: "Ice Beam", type: "ice", power: 90, accuracy: 100, pp: 10 },
      { name: "Freeze-Dry", type: "ice", power: 70, accuracy: 100, pp: 20 }
    ]
  },
  {
    id: 145,
    name: "Zapdos",
    types: ["electric", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/145.png",
    stats: {
      hp: 90,
      attack: 90,
      defense: 85,
      speed: 100
    },
    moves: [
      { name: "Thunder", type: "electric", power: 110, accuracy: 70, pp: 10 },
      { name: "Hurricane", type: "flying", power: 110, accuracy: 70, pp: 10 },
      { name: "Thunderbolt", type: "electric", power: 90, accuracy: 100, pp: 15 },
      { name: "Heat Wave", type: "fire", power: 95, accuracy: 90, pp: 10 }
    ]
  },
  {
    id: 146,
    name: "Moltres",
    types: ["fire", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/146.png",
    stats: {
      hp: 90,
      attack: 100,
      defense: 90,
      speed: 90
    },
    moves: [
      { name: "Fire Blast", type: "fire", power: 110, accuracy: 85, pp: 5 },
      { name: "Hurricane", type: "flying", power: 110, accuracy: 70, pp: 10 },
      { name: "Solar Beam", type: "grass", power: 120, accuracy: 100, pp: 10 },
      { name: "Heat Wave", type: "fire", power: 95, accuracy: 90, pp: 10 }
    ]
  },
  {
    id: 150,
    name: "Mewtwo",
    types: ["psychic"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png",
    stats: {
      hp: 106,
      attack: 110,
      defense: 90,
      speed: 130
    },
    moves: [
      { name: "Psychic", type: "psychic", power: 90, accuracy: 100, pp: 10 },
      { name: "Shadow Ball", type: "ghost", power: 80, accuracy: 100, pp: 15 },
      { name: "Aura Sphere", type: "fighting", power: 80, accuracy: 100, pp: 20 },
      { name: "Psystrike", type: "psychic", power: 100, accuracy: 100, pp: 10 }
    ]
  },
  {
    id: 6,
    name: "Charizard",
    types: ["fire", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/6.png",
    stats: {
      hp: 78,
      attack: 84,
      defense: 78,
      speed: 100
    },
    moves: [
      { name: "Flamethrower", type: "fire", power: 90, accuracy: 100, pp: 15 },
      { name: "Air Slash", type: "flying", power: 75, accuracy: 95, pp: 15 },
      { name: "Dragon Claw", type: "dragon", power: 80, accuracy: 100, pp: 15 },
      { name: "Fire Blast", type: "fire", power: 110, accuracy: 85, pp: 5 }
    ]
  },
  {
    id: 9,
    name: "Blastoise",
    types: ["water"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/9.png",
    stats: {
      hp: 79,
      attack: 83,
      defense: 100,
      speed: 78
    },
    moves: [
      { name: "Hydro Pump", type: "water", power: 110, accuracy: 80, pp: 5 },
      { name: "Ice Beam", type: "ice", power: 90, accuracy: 100, pp: 10 },
      { name: "Earthquake", type: "ground", power: 100, accuracy: 100, pp: 10 },
      { name: "Flash Cannon", type: "steel", power: 80, accuracy: 100, pp: 10 }
    ]
  },
  {
    id: 144,
    name: "Articuno",
    types: ["ice", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/144.png",
    stats: {
      hp: 90,
      attack: 85,
      defense: 100,
      speed: 85
    },
    moves: [
      { name: "Blizzard", type: "ice", power: 110, accuracy: 70, pp: 5 },
      { name: "Hurricane", type: "flying", power: 110, accuracy: 70, pp: 10 },
      { name: "Ice Beam", type: "ice", power: 90, accuracy: 100, pp: 10 },
      { name: "Freeze-Dry", type: "ice", power: 70, accuracy: 100, pp: 20 }
    ]
  },
  {
    id: 145,
    name: "Zapdos",
    types: ["electric", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/145.png",
    stats: {
      hp: 90,
      attack: 90,
      defense: 85,
      speed: 100
    },
    moves: [
      { name: "Thunder", type: "electric", power: 110, accuracy: 70, pp: 10 },
      { name: "Drill Peck", type: "flying", power: 80, accuracy: 100, pp: 20 },
      { name: "Thunder Wave", type: "electric", power: 0, accuracy: 90, pp: 20 },
      { name: "Heat Wave", type: "fire", power: 95, accuracy: 90, pp: 10 }
    ]
  },
  {
    id: 146,
    name: "Moltres",
    types: ["fire", "flying"],
    imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/146.png",
    stats: {
      hp: 90,
      attack: 100,
      defense: 90,
      speed: 90
    },
    moves: [
      { name: "Fire Blast", type: "fire", power: 110, accuracy: 85, pp: 5 },
      { name: "Hurricane", type: "flying", power: 110, accuracy: 70, pp: 10 },
      { name: "Solar Beam", type: "grass", power: 120, accuracy: 100, pp: 10 },
      { name: "Overheat", type: "fire", power: 130, accuracy: 90, pp: 5 }
    ]
  }
];

export async function getPokemonData(): Promise<Pokemon[]> {
  try {
    console.log("Attempting to fetch Pokémon data from MCP server...");
    
    // Try to get data from MCP server
    const mcpData = await mcpClient.getPokemonList();
    
    if (mcpData && mcpData.length > 0) {
      console.log("Successfully loaded Pokémon data from MCP server");
      return mcpData;
    }
    
    throw new Error("No data from MCP server");
  } catch (error) {
    console.warn("MCP server unavailable, using fallback data:", error);
    
    // Return fallback data
    return fallbackPokemon;
  }
}

export function getPokemonById(id: number): Pokemon | undefined {
  return fallbackPokemon.find(pokemon => pokemon.id === id);
}

export function getPokemonByName(name: string): Pokemon | undefined {
  return fallbackPokemon.find(pokemon => 
    pokemon.name.toLowerCase() === name.toLowerCase()
  );
}
