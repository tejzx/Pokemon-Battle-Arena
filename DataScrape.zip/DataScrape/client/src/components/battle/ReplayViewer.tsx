import { useState } from 'react';
import { useReplay } from '../../lib/stores/useReplay';
import { useGame } from '../../lib/stores/useGame';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';

export function ReplayViewer() {
  const { savedReplays, currentPlayback, playbackSpeed, loadReplay, deleteReplay, setPlaybackSpeed } = useReplay();
  const { trainerName } = useGame();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredReplays = savedReplays.filter(replay =>
    replay.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    replay.playerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-800 to-gray-900 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-white text-black mb-6">
          <CardHeader>
            <CardTitle className="text-center text-3xl font-bold">
              🎬 Battle Replays & Highlights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-6">
              <Input 
                placeholder="Search replays..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1"
              />
              <Button 
                onClick={() => window.location.reload()}
                variant="outline"
              >
                ← Back to Game
              </Button>
            </div>

            {currentPlayback && (
              <Card className="mb-6 bg-blue-50">
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold mb-4">Now Playing: {currentPlayback.title}</h3>
                  
                  <div className="flex items-center gap-4 mb-4">
                    <Button 
                      onClick={() => setPlaybackSpeed(0.5)}
                      variant={playbackSpeed === 0.5 ? "default" : "outline"}
                      size="sm"
                    >
                      0.5x
                    </Button>
                    <Button 
                      onClick={() => setPlaybackSpeed(1)}
                      variant={playbackSpeed === 1 ? "default" : "outline"}
                      size="sm"
                    >
                      1x
                    </Button>
                    <Button 
                      onClick={() => setPlaybackSpeed(2)}
                      variant={playbackSpeed === 2 ? "default" : "outline"}
                      size="sm"
                    >
                      2x
                    </Button>
                  </div>

                  <div className="bg-gray-200 rounded p-3">
                    <h4 className="font-semibold mb-2">Battle Actions:</h4>
                    <div className="max-h-48 overflow-y-auto space-y-1">
                      {currentPlayback.actions.map((action, index) => (
                        <div key={action.id} className="text-sm flex items-center gap-2">
                          <span className="text-gray-500 w-12">{index + 1}.</span>
                          <span className="flex-1">{action.description}</span>
                          {currentPlayback.highlights.some(h => h.id === action.id) && (
                            <Badge className="bg-yellow-500">⭐</Badge>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {currentPlayback.highlights.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">🌟 Highlights:</h4>
                      <div className="space-y-1">
                        {currentPlayback.highlights.map((highlight) => (
                          <div key={highlight.id} className="text-sm bg-yellow-100 p-2 rounded">
                            {highlight.description}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {filteredReplays.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredReplays.map((replay) => (
                  <Card key={replay.id} className="border hover:shadow-lg transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-bold text-lg">{replay.title}</h3>
                        <Badge className={replay.winner === replay.playerName ? 'bg-green-500' : 'bg-red-500'}>
                          {replay.winner === replay.playerName ? 'Won' : 'Lost'}
                        </Badge>
                      </div>
                      
                      <div className="text-sm text-gray-600 mb-3">
                        <div>📅 {new Date(replay.date).toLocaleDateString()}</div>
                        <div>⚔️ {replay.playerName} vs {replay.enemyName}</div>
                        <div>⏱️ Duration: {formatDuration(replay.duration)}</div>
                        <div>🎬 {replay.actions.length} actions</div>
                        {replay.highlights.length > 0 && (
                          <div>⭐ {replay.highlights.length} highlights</div>
                        )}
                      </div>

                      <div className="flex gap-2">
                        <Button 
                          onClick={() => loadReplay(replay.id)}
                          className="bg-blue-500 hover:bg-blue-600 flex-1"
                          size="sm"
                        >
                          🎬 Watch
                        </Button>
                        <Button 
                          onClick={() => deleteReplay(replay.id)}
                          variant="destructive"
                          size="sm"
                        >
                          🗑️
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center p-8 text-gray-500">
                <h3 className="text-xl font-semibold mb-2">No Replays Found</h3>
                <p>Battle some Pokémon to create epic replays!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}