import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { useMultiplayer } from "../../lib/stores/useMultiplayer";

interface WelcomeScreenProps {
  onTrainerNameSet: (name: string) => void;
}

export function WelcomeScreen({ onTrainerNameSet }: WelcomeScreenProps) {
  const [showPokeball, setShowPokeball] = useState(true);
  const [showWelcome, setShowWelcome] = useState(false);
  const [trainerName, setTrainerName] = useState("");
  const [showMenu, setShowMenu] = useState(false);
  const { setGameMode } = useMultiplayer();

  useEffect(() => {
    // Pokéball opening animation sequence
    const timer1 = setTimeout(() => {
      setShowPokeball(false);
      setShowWelcome(true);
    }, 2000);

    return () => clearTimeout(timer1);
  }, []);

  const handleStartGame = () => {
    if (trainerName.trim()) {
      onTrainerNameSet(trainerName.trim());
    }
  };

  const handleMultiplayer = () => {
    if (trainerName.trim()) {
      onTrainerNameSet(trainerName.trim());
      setGameMode('multiplayer');
    }
  };

  const handleShowMenu = () => {
    setShowMenu(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-blue-600 via-purple-600 to-red-500">
      <AnimatePresence mode="wait">
        {showPokeball && (
          <motion.div
            key="pokeball"
            initial={{ scale: 0, rotate: 0 }}
            animate={{ 
              scale: [1, 1.2, 1], 
              rotate: [0, 180, 360],
              y: [0, -20, 0]
            }}
            exit={{ 
              scale: 0, 
              rotate: 720,
              transition: { duration: 0.8, ease: "easeInOut" }
            }}
            transition={{ 
              duration: 1.5, 
              repeat: 1,
              ease: "easeInOut"
            }}
            className="relative"
          >
            {/* Pokéball SVG */}
            <svg width="200" height="200" viewBox="0 0 200 200" className="drop-shadow-2xl">
              {/* Top half - red */}
              <path
                d="M100 20 A80 80 0 0 1 180 100 L20 100 A80 80 0 0 1 100 20 Z"
                fill="#DC2626"
                stroke="#000"
                strokeWidth="3"
              />
              {/* Bottom half - white */}
              <path
                d="M100 180 A80 80 0 0 1 20 100 L180 100 A80 80 0 0 1 100 180 Z"
                fill="#F9FAFB"
                stroke="#000"
                strokeWidth="3"
              />
              {/* Middle line */}
              <line x1="20" y1="100" x2="180" y2="100" stroke="#000" strokeWidth="6"/>
              {/* Center button */}
              <circle cx="100" cy="100" r="15" fill="#F9FAFB" stroke="#000" strokeWidth="3"/>
              <circle cx="100" cy="100" r="8" fill="#E5E7EB"/>
            </svg>
            
            {/* Sparkle effects */}
            <motion.div
              animate={{ 
                scale: [1, 1.5, 1],
                opacity: [0.7, 1, 0.7]
              }}
              transition={{ 
                duration: 1, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute inset-0 rounded-full bg-white opacity-20 blur-xl"
            />
          </motion.div>
        )}

        {showWelcome && (
          <motion.div
            key="welcome"
            initial={{ scale: 0, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            transition={{ 
              duration: 0.8, 
              ease: "backOut",
              staggerChildren: 0.2
            }}
            className="text-center max-w-md mx-4"
          >
            <Card className="bg-white/90 backdrop-blur-md shadow-2xl border-2 border-yellow-400">
              <CardHeader className="text-center pb-4">
                <motion.div
                  initial={{ y: -20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <CardTitle className="text-4xl font-bold bg-gradient-to-r from-yellow-600 to-red-600 bg-clip-text text-transparent">
                    Welcome to
                  </CardTitle>
                  <motion.h1
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="text-5xl font-extrabold mt-2 bg-gradient-to-r from-blue-600 via-purple-600 to-red-600 bg-clip-text text-transparent"
                  >
                    Pokémon Battle Arena
                  </motion.h1>
                </motion.div>
              </CardHeader>

              <CardContent className="space-y-6">
                <motion.div
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.7 }}
                  className="space-y-3"
                >
                  <label className="block text-lg font-semibold text-gray-800">
                    Enter your Trainer Name:
                  </label>
                  <Input
                    type="text"
                    placeholder="Ash, Misty, Brock..."
                    value={trainerName}
                    onChange={(e) => setTrainerName(e.target.value)}
                    className="text-lg p-4 border-2 border-blue-300 focus:border-yellow-400 rounded-lg"
                    onKeyPress={(e) => e.key === 'Enter' && handleStartGame()}
                    autoFocus
                  />
                </motion.div>

                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.9 }}
                  className="space-y-3"
                >
                  {!showMenu ? (
                    <>
                      <Button
                        onClick={handleStartGame}
                        disabled={!trainerName.trim()}
                        className="w-full py-4 text-xl font-bold bg-gradient-to-r from-yellow-500 to-red-500 hover:from-yellow-600 hover:to-red-600 text-white shadow-lg transform hover:scale-105 transition-all duration-200"
                      >
                        🎮 Single Player Battle
                      </Button>
                      <Button
                        onClick={handleShowMenu}
                        disabled={!trainerName.trim()}
                        variant="outline"
                        className="w-full py-3 text-lg font-semibold border-2 border-blue-400 text-blue-600 hover:bg-blue-50"
                      >
                        ⚡ More Options
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button
                        onClick={handleStartGame}
                        disabled={!trainerName.trim()}
                        className="w-full py-3 text-lg font-bold bg-gradient-to-r from-yellow-500 to-red-500 hover:from-yellow-600 hover:to-red-600 text-white"
                      >
                        🎮 Single Player
                      </Button>
                      <Button
                        onClick={handleMultiplayer}
                        disabled={!trainerName.trim()}
                        className="w-full py-3 text-lg font-bold bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
                      >
                        🌐 Multiplayer Battle
                      </Button>
                      <Button
                        onClick={() => window.open('/replays', '_blank')}
                        disabled={!trainerName.trim()}
                        className="w-full py-3 text-lg font-bold bg-gradient-to-r from-gray-600 to-gray-800 hover:from-gray-700 hover:to-gray-900 text-white"
                      >
                        🎬 View Replays
                      </Button>
                      <Button
                        onClick={() => setShowMenu(false)}
                        variant="outline"
                        className="w-full py-2 text-sm"
                      >
                        ← Back
                      </Button>
                    </>
                  )}
                </motion.div>

                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.1 }}
                  className="text-sm text-gray-600 italic"
                >
                  Choose your Pokémon and battle with TV show-style graphics!
                </motion.p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}