import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { Text, useTexture } from "@react-three/drei";
import { useBattle } from "../../lib/stores/useBattle";
import * as THREE from "three";

interface EnhancedPokemonProps {
  pokemonData: any;
  position: [number, number, number];
  isPlayer: boolean;
  isActive: boolean;
}

export function EnhancedPokemon({ pokemonData, position, isPlayer, isActive }: EnhancedPokemonProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const groupRef = useRef<THREE.Group>(null);
  const spriteRef = useRef<THREE.Sprite>(null);
  const [isAttacking, setIsAttacking] = useState(false);
  const [isJumping, setIsJumping] = useState(false);
  const [isMoving, setIsMoving] = useState(false);
  const [animationPhase, setAnimationPhase] = useState(0);
  
  const { isAttacking: globalAttacking, currentTurn, lastAttack } = useBattle();
  
  // Enhanced animation states
  const [currentAnimation, setCurrentAnimation] = useState<'idle' | 'attack' | 'jump' | 'move' | 'defend' | 'hurt'>('idle');
  const [animationProgress, setAnimationProgress] = useState(0);
  
  // Load Pokémon sprite texture with error handling
  const [spriteTexture, setSpriteTexture] = useState<THREE.Texture | null>(null);
  
  useEffect(() => {
    const loader = new THREE.TextureLoader();
    loader.load(
      pokemonData.imageUrl,
      (texture) => {
        texture.minFilter = THREE.LinearFilter;
        texture.magFilter = THREE.LinearFilter;
        setSpriteTexture(texture);
      },
      undefined,
      (error) => {
        console.warn('Failed to load Pokémon texture:', error);
        // Create a fallback colored texture
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = getTypeColor(pokemonData.types[0]);
          ctx.fillRect(0, 0, 64, 64);
          ctx.fillStyle = '#fff';
          ctx.font = '12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(pokemonData.name.slice(0, 8), 32, 35);
        }
        const fallbackTexture = new THREE.CanvasTexture(canvas);
        setSpriteTexture(fallbackTexture);
      }
    );
  }, [pokemonData.imageUrl, pokemonData.name, pokemonData.types]);
  
  // Get type color for the Pokémon
  const getTypeColor = (type: string) => {
    const colors: { [key: string]: string } = {
      fire: "#FF6666",
      water: "#6666FF", 
      grass: "#66FF66",
      electric: "#FFFF66",
      psychic: "#FF66FF",
      ice: "#66FFFF",
      dragon: "#9966FF",
      dark: "#666666",
      fighting: "#CC6666",
      poison: "#996699",
      ground: "#E6CC66",
      flying: "#99CCFF",
      bug: "#99CC66",
      rock: "#CC9966",
      ghost: "#9999CC",
      steel: "#B3B3CC",
      normal: "#CCCCCC"
    };
    return colors[type] || "#CCCCCC";
  };

  // Enhanced movement animations based on attack type
  const performAttackAnimation = (attackType: string) => {
    setCurrentAnimation('attack');
    setAnimationProgress(0);
    
    switch (attackType) {
      case 'electric':
        // Electric dash - quick forward movement with sparks
        setIsMoving(true);
        setTimeout(() => setIsMoving(false), 300);
        break;
      case 'fire':
        // Fire arc - upward jump with flame trail
        setIsJumping(true);
        setTimeout(() => setIsJumping(false), 600);
        break;
      case 'water':
        // Water flow - side-to-side wave motion
        setIsMoving(true);
        setTimeout(() => setIsMoving(false), 800);
        break;
      case 'psychic':
        // Psychic teleport - disappear and reappear
        setCurrentAnimation('jump');
        setTimeout(() => setCurrentAnimation('attack'), 400);
        setTimeout(() => setCurrentAnimation('idle'), 800);
        break;
      default:
        // Default physical attack
        setIsJumping(true);
        setTimeout(() => setIsJumping(false), 400);
    }
    
    setTimeout(() => {
      setCurrentAnimation('idle');
      setAnimationProgress(0);
    }, 1000);
  };

  // React to battle state changes
  useEffect(() => {
    if (globalAttacking && ((isPlayer && currentTurn === 'player') || (!isPlayer && currentTurn === 'enemy'))) {
      if (lastAttack) {
        performAttackAnimation(lastAttack.type);
      }
    }
  }, [globalAttacking, currentTurn, isPlayer, lastAttack?.name]);

  // Enhanced animation frame
  useFrame((state, delta) => {
    if (!groupRef.current) return;
    
    const time = state.clock.elapsedTime;
    const baseY = position[1];
    
    // Idle breathing animation
    if (currentAnimation === 'idle') {
      groupRef.current.position.y = baseY + Math.sin(time * 2) * 0.05;
      groupRef.current.rotation.z = Math.sin(time * 1.5) * 0.02;
    }
    
    // Attack animations
    else if (currentAnimation === 'attack') {
      setAnimationProgress(prev => Math.min(prev + delta * 3, 1));
      
      if (lastAttack?.type === 'electric') {
        // Electric dash animation
        const dashProgress = Math.sin(animationProgress * Math.PI);
        groupRef.current.position.x = position[0] + (isPlayer ? dashProgress * 2 : -dashProgress * 2);
        groupRef.current.position.y = baseY + dashProgress * 0.3;
        groupRef.current.scale.setScalar(1 + dashProgress * 0.2);
      }
      else if (lastAttack?.type === 'fire') {
        // Fire arc animation
        const arcProgress = animationProgress;
        groupRef.current.position.y = baseY + Math.sin(arcProgress * Math.PI) * 1.5;
        groupRef.current.position.x = position[0] + (isPlayer ? Math.cos(arcProgress * Math.PI) * 0.5 : -Math.cos(arcProgress * Math.PI) * 0.5);
        groupRef.current.rotation.z = Math.sin(arcProgress * Math.PI * 2) * 0.2;
      }
      else if (lastAttack?.type === 'water') {
        // Water flow animation
        const waveProgress = animationProgress;
        groupRef.current.position.x = position[0] + Math.sin(waveProgress * Math.PI * 3) * 0.8;
        groupRef.current.position.y = baseY + Math.sin(waveProgress * Math.PI) * 0.4;
        groupRef.current.rotation.y = Math.sin(waveProgress * Math.PI * 2) * 0.1;
      }
      else if (lastAttack?.type === 'psychic') {
        // Psychic teleport animation
        const teleportProgress = animationProgress;
        if (teleportProgress < 0.3) {
          groupRef.current.scale.setScalar(1 - teleportProgress * 3);
          groupRef.current.rotation.y = teleportProgress * Math.PI * 4;
        } else if (teleportProgress > 0.7) {
          const appearProgress = (teleportProgress - 0.7) / 0.3;
          groupRef.current.scale.setScalar(appearProgress);
          groupRef.current.position.x = position[0] + (1 - appearProgress) * (isPlayer ? -2 : 2);
        } else {
          groupRef.current.scale.setScalar(0.1);
          groupRef.current.position.x = position[0] + (isPlayer ? -2 : 2);
        }
      }
      else {
        // Default physical attack
        const bounceProgress = Math.sin(animationProgress * Math.PI);
        groupRef.current.position.y = baseY + bounceProgress * 0.6;
        groupRef.current.scale.setScalar(1 + bounceProgress * 0.15);
      }
    }
    
    // Jump animation for defensive moves
    else if (currentAnimation === 'jump') {
      const jumpProgress = Math.sin(animationProgress * Math.PI);
      groupRef.current.position.y = baseY + jumpProgress * 1.2;
      groupRef.current.rotation.z = jumpProgress * 0.3;
    }
    
    // Active highlighting
    if (isActive) {
      const pulseIntensity = 0.1 + Math.sin(time * 4) * 0.05;
      groupRef.current.scale.setScalar(1 + pulseIntensity);
    }
    
    // Reset position gradually when animation ends
    if (currentAnimation === 'idle' && animationProgress === 0) {
      groupRef.current.position.x = THREE.MathUtils.lerp(groupRef.current.position.x, position[0], 0.1);
      groupRef.current.position.z = THREE.MathUtils.lerp(groupRef.current.position.z, position[2], 0.1);
      groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, 0, 0.1);
      groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, 0, 0.1);
      groupRef.current.scale.lerp(new THREE.Vector3(1, 1, 1), 0.1);
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Pokémon Sprite */}
      {spriteTexture && (
        <sprite ref={spriteRef} scale={[3, 3, 1]} position={[0, 1, 0]}>
          <spriteMaterial map={spriteTexture} transparent />
        </sprite>
      )}
      
      {/* Shadow/Base */}
      <mesh position={[0, 0.1, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[1, 16]} />
        <meshBasicMaterial color={getTypeColor(pokemonData.types[0])} opacity={0.3} transparent />
      </mesh>
      
      {/* Health bar */}
      <group position={[0, 2.5, 0]}>
        <mesh position={[-1, 0, 0]}>
          <planeGeometry args={[2, 0.2]} />
          <meshBasicMaterial color="#ff4444" />
        </mesh>
        <mesh position={[-1 + (pokemonData.currentHp / pokemonData.stats.hp), 0, 0.01]}>
          <planeGeometry args={[2 * (pokemonData.currentHp / pokemonData.stats.hp), 0.18]} />
          <meshBasicMaterial color="#44ff44" />
        </mesh>
        
        {/* Pokémon name */}
        <Text
          position={[0, 0.4, 0]}
          fontSize={0.3}
          color="white"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="black"
        >
          {pokemonData.name}
        </Text>
      </group>
      
      {/* Type indicator effects */}
      {currentAnimation === 'attack' && lastAttack && (
        <group>
          {lastAttack.type === 'electric' && (
            <mesh position={[0, 1, 0]}>
              <sphereGeometry args={[0.1, 8, 8]} />
              <meshBasicMaterial color="#ffff00" opacity={0.7} transparent />
            </mesh>
          )}
          {lastAttack.type === 'fire' && (
            <mesh position={[0, 1, 0]}>
              <coneGeometry args={[0.2, 0.5, 8]} />
              <meshBasicMaterial color="#ff6600" opacity={0.8} transparent />
            </mesh>
          )}
        </group>
      )}
    </group>
  );
}