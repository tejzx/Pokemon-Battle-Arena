import { create } from "zustand";
import { getPokemonData } from "../pokemonData";

interface PokemonMove {
  name: string;
  type: string;
  power: number;
  accuracy: number;
  pp: number;
}

interface Pokemon {
  id: number;
  name: string;
  types: string[];
  imageUrl: string;
  stats: {
    hp: number;
    attack: number;
    defense: number;
    speed: number;
  };
  moves: PokemonMove[];
}

interface PokemonState {
  availablePokemon: Pokemon[];
  isLoading: boolean;
  error: string | null;
  
  // Actions
  loadPokemon: () => Promise<void>;
  addPokemon: (pokemon: Pokemon) => void;
}

export const usePokemon = create<PokemonState>((set, get) => ({
  availablePokemon: [],
  isLoading: false,
  error: null,

  loadPokemon: async () => {
    set({ isLoading: true, error: null });
    
    try {
      // Load initial Pokémon data
      const pokemonData = await getPokemonData();
      set({ 
        availablePokemon: pokemonData, 
        isLoading: false 
      });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : "Failed to load Pokémon", 
        isLoading: false 
      });
    }
  },

  addPokemon: (pokemon) => {
    set(state => ({
      availablePokemon: [...state.availablePokemon, pokemon]
    }));
  }
}));

// Auto-load Pokémon when store is created
usePokemon.getState().loadPokemon();
