import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import { useBattle } from "./lib/stores/useBattle";
import { useGame } from "./lib/stores/useGame";
import { usePokemon } from "./lib/stores/usePokemon";
import { useMultiplayer } from "./lib/stores/useMultiplayer";
import { useReplay } from "./lib/stores/useReplay";
import { WelcomeScreen } from "./components/battle/WelcomeScreen";
import { BattleArena } from "./components/battle/BattleArena";
import { BattleUI } from "./components/battle/BattleUI";
import { PokemonSelector } from "./components/battle/PokemonSelector";
import { SoundManager } from "./components/battle/SoundManager";
import { Lights } from "./components/battle/Lights";
import { MultiplayerLobby } from "./components/battle/MultiplayerLobby";
import { ReplayViewer } from "./components/battle/ReplayViewer";
import "@fontsource/inter";

// Define control keys for the battle game
const controls = [
  { name: "select", keys: ["Enter", "Space"] },
  { name: "cancel", keys: ["Escape"] },
  { name: "up", keys: ["ArrowUp", "KeyW"] },
  { name: "down", keys: ["ArrowDown", "KeyS"] },
  { name: "left", keys: ["ArrowLeft", "KeyA"] },
  { name: "right", keys: ["ArrowRight", "KeyD"] },
  { name: "attack1", keys: ["KeyJ"] },
  { name: "attack2", keys: ["KeyK"] },
  { name: "attack3", keys: ["KeyL"] },
  { name: "attack4", keys: ["KeyI"] },
];

function App() {
  const [showCanvas, setShowCanvas] = useState(false);
  
  // Initialize all stores at component level
  const { battlePhase } = useBattle();
  const { phase: gamePhase, setTrainerName } = useGame();
  const { loadPokemon } = usePokemon();
  const { gameMode } = useMultiplayer();
  const { startRecording } = useReplay();
  
  // Load Pokemon data and show canvas once everything is ready
  useEffect(() => {
    const initializeApp = async () => {
      await loadPokemon();
      setShowCanvas(true);
    };
    initializeApp();
  }, [loadPokemon]);

  // Handle trainer name submission
  const handleTrainerNameSet = (name: string) => {
    setTrainerName(name);
  };

  // Show welcome screen first
  if (gamePhase === 'welcome') {
    return <WelcomeScreen onTrainerNameSet={handleTrainerNameSet} />;
  }

  // Show multiplayer lobby if in multiplayer mode
  if (gameMode === 'multiplayer') {
    return <MultiplayerLobby />;
  }

  // Show replay viewer if requested (temporary for now)

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      {showCanvas && (
        <KeyboardControls map={controls}>
          {battlePhase === 'selection' && <PokemonSelector />}

          {(battlePhase === 'battle' || battlePhase === 'victory') && (
            <>
              <Canvas
                shadows
                camera={{
                  position: [0, 5, 10],
                  fov: 45,
                  near: 0.1,
                  far: 1000
                }}
                gl={{
                  antialias: true,
                  powerPreference: "high-performance"
                }}
              >
                <color attach="background" args={["#87CEEB"]} />

                {/* Lighting */}
                <Lights />

                <Suspense fallback={null}>
                  <BattleArena />
                </Suspense>
              </Canvas>
              <BattleUI />
            </>
          )}

          <SoundManager />
        </KeyboardControls>
      )}
    </div>
  );
}

export default App;
