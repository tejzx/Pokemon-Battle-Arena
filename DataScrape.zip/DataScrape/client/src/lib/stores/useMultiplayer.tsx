import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

type GameMode = 'single' | 'multiplayer' | 'spectate';
type ConnectionStatus = 'disconnected' | 'connecting' | 'connected';

interface Player {
  id: string;
  name: string;
  pokemon: any;
  isReady: boolean;
}

interface MultiplayerState {
  gameMode: GameMode;
  connectionStatus: ConnectionStatus;
  roomId: string | null;
  players: Player[];
  isHost: boolean;
  
  // Actions
  setGameMode: (mode: GameMode) => void;
  createRoom: () => void;
  joinRoom: (roomId: string) => void;
  leaveRoom: () => void;
  setPlayerReady: (playerId: string, isReady: boolean) => void;
  addPlayer: (player: Player) => void;
  removePlayer: (playerId: string) => void;
}

export const useMultiplayer = create<MultiplayerState>()(
  subscribeWithSelector((set, get) => ({
    gameMode: 'single',
    connectionStatus: 'disconnected',
    roomId: null,
    players: [],
    isHost: false,
    
    setGameMode: (mode) => {
      set({ gameMode: mode });
    },
    
    createRoom: () => {
      const roomId = Math.random().toString(36).substring(2, 8).toUpperCase();
      set({ 
        roomId, 
        isHost: true, 
        connectionStatus: 'connected',
        players: []
      });
    },
    
    joinRoom: (roomId) => {
      set({ 
        roomId, 
        isHost: false, 
        connectionStatus: 'connecting'
      });
      
      // Simulate connection
      setTimeout(() => {
        set({ connectionStatus: 'connected' });
      }, 1000);
    },
    
    leaveRoom: () => {
      set({ 
        roomId: null, 
        isHost: false, 
        connectionStatus: 'disconnected',
        players: [],
        gameMode: 'single'
      });
    },
    
    setPlayerReady: (playerId, isReady) => {
      set(state => ({
        players: state.players.map(p => 
          p.id === playerId ? { ...p, isReady } : p
        )
      }));
    },
    
    addPlayer: (player) => {
      set(state => ({
        players: [...state.players, player]
      }));
    },
    
    removePlayer: (playerId) => {
      set(state => ({
        players: state.players.filter(p => p.id !== playerId)
      }));
    }
  }))
);