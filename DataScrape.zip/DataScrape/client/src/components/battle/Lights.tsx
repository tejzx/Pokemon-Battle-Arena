import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export function Lights() {
  const directionalRef = useRef<THREE.DirectionalLight>(null);

  useFrame((state) => {
    if (directionalRef.current) {
      // Subtle light movement for dynamic shadows
      directionalRef.current.position.x = Math.sin(state.clock.elapsedTime * 0.5) * 2;
      directionalRef.current.position.z = Math.cos(state.clock.elapsedTime * 0.5) * 2;
    }
  });

  return (
    <>
      {/* Ambient light for general illumination */}
      <ambientLight intensity={0.4} color="#ffffff" />
      
      {/* Main directional light (sun) */}
      <directionalLight
        ref={directionalRef}
        position={[10, 10, 5]}
        intensity={1}
        color="#ffffff"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />

      {/* Fill light to reduce harsh shadows */}
      <directionalLight
        position={[-5, 5, -5]}
        intensity={0.3}
        color="#87CEEB"
      />

      {/* Point light for dramatic effect */}
      <pointLight
        position={[0, 8, 0]}
        intensity={0.5}
        color="#ffffff"
        distance={20}
      />
    </>
  );
}
