import { useState } from 'react';
import { useMultiplayer } from '../../lib/stores/useMultiplayer';
import { useGame } from '../../lib/stores/useGame';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';

export function MultiplayerLobby() {
  const { gameMode, connectionStatus, roomId, players, isHost, createRoom, joinRoom, leaveRoom, setGameMode } = useMultiplayer();
  const { trainerName } = useGame();
  const [roomInput, setRoomInput] = useState('');

  const handleCreateRoom = () => {
    createRoom();
  };

  const handleJoinRoom = () => {
    if (roomInput.trim()) {
      joinRoom(roomInput.trim().toUpperCase());
    }
  };

  const handleBackToSingle = () => {
    setGameMode('single');
    leaveRoom();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-600 to-blue-600 p-4">
      <div className="max-w-2xl mx-auto">
        <Card className="bg-white text-black mb-6">
          <CardHeader>
            <CardTitle className="text-center text-3xl font-bold">
              🌐 Multiplayer Arena
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-6">
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white px-4 py-2 rounded-full font-semibold mb-4">
                <span>👨‍🎓 Trainer {trainerName}</span>
              </div>
            </div>

            {gameMode === 'single' && (
              <div className="space-y-4">
                <div className="text-center">
                  <h3 className="text-xl font-semibold mb-4">Choose Your Battle Mode</h3>
                </div>
                
                <Button 
                  onClick={handleCreateRoom}
                  className="w-full bg-green-500 hover:bg-green-600 text-white"
                >
                  🏆 Create Battle Room
                </Button>
                
                <div className="flex gap-2">
                  <Input 
                    placeholder="Enter Room Code (e.g., ABCD12)"
                    value={roomInput}
                    onChange={(e) => setRoomInput(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={handleJoinRoom} className="bg-blue-500 hover:bg-blue-600">
                    Join
                  </Button>
                </div>
                
                <Button 
                  onClick={handleBackToSingle}
                  variant="outline" 
                  className="w-full"
                >
                  ← Back to Single Player
                </Button>
              </div>
            )}

            {roomId && (
              <div className="space-y-4">
                <div className="text-center">
                  <h3 className="text-xl font-semibold mb-2">Battle Room</h3>
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <span className="text-sm text-gray-600">Room Code:</span>
                    <div className="text-2xl font-bold font-mono">{roomId}</div>
                  </div>
                  
                  <div className="mt-4">
                    <Badge className={connectionStatus === 'connected' ? 'bg-green-500' : 'bg-yellow-500'}>
                      {connectionStatus === 'connected' ? '🟢 Connected' : '🟡 Connecting...'}
                    </Badge>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-semibold mb-3">Players in Room:</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 bg-blue-100 rounded">
                      <span>{trainerName} {isHost ? '(Host)' : ''}</span>
                      <Badge className="bg-green-500">Ready</Badge>
                    </div>
                    
                    {players.map((player) => (
                      <div key={player.id} className="flex items-center justify-between p-2 bg-gray-100 rounded">
                        <span>{player.name}</span>
                        <Badge className={player.isReady ? 'bg-green-500' : 'bg-gray-500'}>
                          {player.isReady ? 'Ready' : 'Not Ready'}
                        </Badge>
                      </div>
                    ))}
                    
                    {players.length === 0 && (
                      <div className="text-center p-4 text-gray-500">
                        Waiting for other players to join...
                      </div>
                    )}
                  </div>
                </div>

                {isHost && players.length > 0 && (
                  <Button className="w-full bg-purple-500 hover:bg-purple-600">
                    🚀 Start Multiplayer Battle
                  </Button>
                )}

                <Button 
                  onClick={handleBackToSingle}
                  variant="outline" 
                  className="w-full"
                >
                  Leave Room
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}