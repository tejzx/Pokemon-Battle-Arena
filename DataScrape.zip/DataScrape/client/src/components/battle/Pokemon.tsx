import { useRef, useState, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { Text, useTexture } from "@react-three/drei";
import { useBattle } from "../../lib/stores/useBattle";
import * as THREE from "three";

interface PokemonProps {
  pokemonData: any;
  position: [number, number, number];
  isPlayer: boolean;
  isActive: boolean;
}

export function Pokemon({ pokemonData, position, isPlayer, isActive }: PokemonProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const groupRef = useRef<THREE.Group>(null);
  const spriteRef = useRef<THREE.Sprite>(null);
  const [isAttacking, setIsAttacking] = useState(false);
  const { isAttacking: globalAttacking, currentTurn } = useBattle();
  
  // Load Pokémon sprite texture with error handling
  const [spriteTexture, setSpriteTexture] = useState<THREE.Texture | null>(null);
  
  useEffect(() => {
    const loader = new THREE.TextureLoader();
    loader.load(
      pokemonData.imageUrl,
      (texture) => {
        texture.minFilter = THREE.LinearFilter;
        texture.magFilter = THREE.LinearFilter;
        setSpriteTexture(texture);
      },
      undefined,
      (error) => {
        console.warn('Failed to load Pokémon texture:', error);
        // Create a fallback colored texture
        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = getTypeColor(pokemonData.types[0]);
          ctx.fillRect(0, 0, 64, 64);
          ctx.fillStyle = '#fff';
          ctx.font = '12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(pokemonData.name.slice(0, 8), 32, 35);
        }
        const fallbackTexture = new THREE.CanvasTexture(canvas);
        setSpriteTexture(fallbackTexture);
      }
    );
  }, [pokemonData.imageUrl, pokemonData.name, pokemonData.types]);
  
  // Get type color for the Pokémon
  const getTypeColor = (type: string) => {
    const colors: { [key: string]: string } = {
      fire: "#FF6666",
      water: "#6666FF",
      grass: "#66FF66",
      electric: "#FFFF66",
      psychic: "#FF66FF",
      ice: "#66FFFF",
      dragon: "#9966FF",
      dark: "#666666",
      fighting: "#CC6666",
      poison: "#996699",
      ground: "#E6CC66",
      flying: "#99CCFF",
      bug: "#99CC66",
      rock: "#CC9966",
      ghost: "#9999CC",
      steel: "#B3B3CC",
      normal: "#CCCCCC"
    };
    return colors[type.toLowerCase()] || "#CCCCCC";
  };

  // Handle attack animation with move-specific effects
  useEffect(() => {
    if (globalAttacking && ((isPlayer && currentTurn === 'player') || (!isPlayer && currentTurn === 'enemy'))) {
      setIsAttacking(true);
      // Different animation durations based on attack type
      const duration = 1200; // Longer for more dramatic effect
      setTimeout(() => setIsAttacking(false), duration);
    }
  }, [globalAttacking, currentTurn, isPlayer]);

  // Enhanced animation system for battle movements
  useFrame((state) => {
    const baseY = 2.5;
    const time = state.clock.elapsedTime;
    
    if (spriteRef.current && groupRef.current) {
      // Base floating animation for active Pokémon
      if (isActive) {
        spriteRef.current.position.y = baseY + Math.sin(time * 2) * 0.15;
        spriteRef.current.scale.setScalar(1 + Math.sin(time * 3) * 0.08);
        
        // Active Pokémon glow pulse
        if (meshRef.current) {
          const glowIntensity = 0.3 + Math.sin(time * 4) * 0.1;
          meshRef.current.material.emissiveIntensity = glowIntensity;
        }
      } else {
        spriteRef.current.position.y = baseY;
        spriteRef.current.scale.setScalar(1);
        if (meshRef.current) {
          meshRef.current.material.emissiveIntensity = 0.1;
        }
      }
      
      // Enhanced attack animations with type-specific movements
      if (isAttacking) {
        const attackProgress = Math.sin(time * 8) * 0.5 + 0.5; // 0 to 1
        const moveDistance = isPlayer ? -1.5 : 1.5;
        const verticalBounce = Math.sin(time * 12) * 0.3;
        
        // Different attack patterns based on primary type
        const primaryType = pokemonData.types[0];
        switch (primaryType) {
          case 'electric':
            // Electric types: Quick dash with lightning-like movement
            spriteRef.current.position.x = Math.sin(time * 20) * 0.2 + (moveDistance * attackProgress);
            spriteRef.current.position.y = baseY + verticalBounce + Math.sin(time * 15) * 0.1;
            spriteRef.current.rotation.z = Math.sin(time * 25) * 0.1;
            break;
          case 'fire':
            // Fire types: Explosive forward movement with upward arc
            spriteRef.current.position.x = moveDistance * Math.pow(attackProgress, 2);
            spriteRef.current.position.y = baseY + Math.sin(attackProgress * Math.PI) * 0.8;
            spriteRef.current.scale.setScalar(1 + attackProgress * 0.3);
            break;
          case 'water':
            // Water types: Flowing wave-like movement
            spriteRef.current.position.x = moveDistance * attackProgress + Math.sin(time * 10) * 0.3;
            spriteRef.current.position.y = baseY + Math.sin(time * 8) * 0.2;
            spriteRef.current.rotation.z = Math.sin(time * 12) * 0.15;
            break;
          case 'grass':
            // Grass types: Swaying attack with growth animation
            spriteRef.current.position.x = moveDistance * attackProgress * 0.7;
            spriteRef.current.position.y = baseY + Math.sin(time * 6) * 0.25;
            spriteRef.current.scale.setScalar(1 + Math.sin(time * 8) * 0.15);
            break;
          case 'psychic':
            // Psychic types: Teleport-like instant movement with rotation
            const teleportPhase = Math.floor(time * 4) % 4;
            spriteRef.current.position.x = teleportPhase < 2 ? 0 : moveDistance * 0.8;
            spriteRef.current.position.y = baseY + Math.sin(time * 10) * 0.3;
            spriteRef.current.rotation.y = time * 5;
            spriteRef.current.material.opacity = 0.7 + Math.sin(time * 20) * 0.3;
            break;
          case 'flying':
            // Flying types: Aerial swoop attack
            spriteRef.current.position.x = moveDistance * attackProgress;
            spriteRef.current.position.y = baseY + Math.sin(attackProgress * Math.PI) * 1.2;
            spriteRef.current.rotation.z = attackProgress * (isPlayer ? -0.3 : 0.3);
            break;
          default:
            // Default: Simple charge attack
            spriteRef.current.position.x = moveDistance * attackProgress * 0.6;
            spriteRef.current.position.y = baseY + verticalBounce;
        }
      } else {
        // Return to normal position
        spriteRef.current.position.x = THREE.MathUtils.lerp(spriteRef.current.position.x, 0, 0.1);
        spriteRef.current.rotation.z = THREE.MathUtils.lerp(spriteRef.current.rotation.z, 0, 0.1);
        spriteRef.current.rotation.y = THREE.MathUtils.lerp(spriteRef.current.rotation.y, 0, 0.1);
      }
      
      // Critical health warning flash
      if (pokemonData.currentHp < pokemonData.stats.hp * 0.2) {
        const criticalFlash = Math.sin(time * 12) * 0.4 + 0.6;
        spriteRef.current.material.opacity = criticalFlash;
        if (meshRef.current) {
          meshRef.current.material.emissive.setHex(0xFF0000);
          meshRef.current.material.emissiveIntensity = criticalFlash * 0.5;
        }
      } else if (pokemonData.currentHp < pokemonData.stats.hp * 0.5) {
        const warningFlash = Math.sin(time * 6) * 0.2 + 0.8;
        spriteRef.current.material.opacity = warningFlash;
      } else {
        spriteRef.current.material.opacity = 1;
      }

      groupRef.current.position.set(...position);
    }
  });

  const primaryType = pokemonData.types[0];
  const typeColor = getTypeColor(primaryType);

  return (
    <group ref={groupRef}>
      {/* Pokémon Sprite */}
      {spriteTexture && (
        <sprite ref={spriteRef} position={[0, 2.5, 0]} scale={[3, 3, 1]}>
          <spriteMaterial 
            map={spriteTexture} 
            transparent 
            alphaTest={0.1}
          />
        </sprite>
      )}

      {/* Glow effect around the Pokémon */}
      <mesh position={[0, 1, 0]} castShadow>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshStandardMaterial 
          color={typeColor} 
          transparent 
          opacity={0.3}
          emissive={typeColor}
          emissiveIntensity={isActive ? 0.2 : 0.1}
        />
      </mesh>

      {/* Health bar */}
      <group position={[0, 2.5, 0]}>
        <mesh position={[0, 0, 0]}>
          <planeGeometry args={[1.5, 0.2]} />
          <meshBasicMaterial color="#333333" />
        </mesh>
        <mesh position={[-(1.5/2) * (1 - pokemonData.currentHp / pokemonData.stats.hp), 0, 0.01]}>
          <planeGeometry args={[1.5 * (pokemonData.currentHp / pokemonData.stats.hp), 0.15]} />
          <meshBasicMaterial color={pokemonData.currentHp / pokemonData.stats.hp > 0.3 ? "#44FF44" : "#FF4444"} />
        </mesh>
      </group>

      {/* Pokémon name */}
      <Text
        position={[0, 3, 0]}
        fontSize={0.3}
        color="white"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="black"
      >
        {pokemonData.name}
      </Text>

      {/* Platform */}
      <mesh position={[0, 0, 0]} receiveShadow>
        <cylinderGeometry args={[1.2, 1.2, 0.1, 16]} />
        <meshStandardMaterial color="#666666" />
      </mesh>
    </group>
  );
}
