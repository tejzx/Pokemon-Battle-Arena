# Overview

This is an AI-powered 3D Pokémon battle simulator built with React, Three.js, and Express.js. The application features a comprehensive gaming platform with TV show-style graphics, multiplayer functionality, dynamic battle environments, and replay systems. The frontend uses React Three Fiber for 3D rendering with enhanced battle animations, type-specific movement patterns, and real Pokémon sprites. The backend provides a REST API with MCP integration for external data sources.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (January 2025)

### New Features Added:
✓ **Multiplayer Functionality**: Complete room-based multiplayer system with lobby, room codes, and player management
✓ **Dynamic Battle Backgrounds**: Environment changes based on Pokémon types (fire, water, electric, psychic, cave, grass)
✓ **Replay & Highlight System**: Battle recording, replay viewing, highlight creation, and playback controls
✓ **Enhanced Welcome Screen**: Added menu options for Single Player, Multiplayer, and Replay viewing
✓ **Improved Scroll Controls**: Fixed Pokémon selection scroll with proper keyboard event handling and debouncing
✓ **Faster Battle Response**: Reduced battle action delays from 1.5s to 0.8s for more responsive gameplay
✓ **TV Show-Style Graphics**: Enhanced with actual Pokémon sprites, particle effects, and type-specific animations

### Technical Improvements:
- Fixed React hooks usage issues and proper store initialization
- Added comprehensive error handling and LSP diagnostic resolution
- Implemented dynamic environment detection based on Pokémon types
- Created modular component architecture for multiplayer and replay features
- Enhanced state management with new stores for multiplayer and replay functionality

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for the main application framework
- **React Three Fiber (@react-three/fiber)** for 3D scene management and WebGL rendering
- **React Three Drei (@react-three/drei)** for additional 3D utilities like controls, text, and textures
- **Zustand** for state management with multiple stores (battle, audio, game, pokémon)
- **Radix UI** components for accessible UI elements
- **Tailwind CSS** with custom theming for styling
- **Vite** as the build tool with hot module replacement

### Backend Architecture
- **Express.js** server with TypeScript
- **RESTful API** design with health check and Pokémon endpoints
- **In-memory storage** using a custom storage class for user data
- **Mock Pokémon API** endpoints that simulate external data sources
- **MCP integration** support for external service communication

### State Management
- **Battle Store**: Manages battle phases, Pokémon data, turns, combat logic, and improved response times
- **Audio Store**: Controls background music, sound effects, and mute functionality
- **Game Store**: Handles overall game phases (welcome, ready, playing, ended) with trainer name system
- **Pokémon Store**: Manages available Pokémon data and loading states with MCP integration
- **Multiplayer Store**: Manages game modes, room creation/joining, player management, and connection status
- **Replay Store**: Handles battle recording, replay saving/loading, highlights, and playback controls

### 3D Graphics System
- **Canvas-based rendering** with shadows and post-processing effects
- **Enhanced keyboard controls** with proper debouncing for smooth navigation
- **Particle systems** for attack effects with type-specific colors and animations
- **Dynamic lighting** with environment-based lighting changes
- **3D Pokémon models** with actual sprite images and type-specific movement patterns
- **Dynamic backgrounds** that change based on Pokémon types and battle conditions
- **TV show-style graphics** with enhanced visual effects and animations

### Battle System
- **Turn-based combat** with improved response times (reduced from 1.5s to 0.8s)
- **Type effectiveness calculations** using a comprehensive type chart
- **Damage formula** based on attack, defense, and move power
- **Four-move system** per Pokémon with PP tracking
- **Battle phases**: selection, battle, victory with enhanced animations
- **Type-specific movements**: Electric dash, Fire arc, Water flow, Psychic teleport
- **Battle recording** for replay and highlight systems
- **Multiplayer battle support** with room-based matchmaking

### Data Layer
- **Drizzle ORM** configured for PostgreSQL with schema definitions
- **User schema** with username/password fields
- **Fallback data system** for when external services are unavailable
- **Mock data** for development and testing

## External Dependencies

### Database
- **PostgreSQL** via Neon Database (@neondatabase/serverless)
- **Drizzle ORM** for database schema and migrations
- **Environment-based configuration** with DATABASE_URL

### Third-party Services
- **MCP (Model Context Protocol)** integration for external Pokémon data
- **Font loading** via Fontsource for Inter font family

### Development Tools
- **ESBuild** for server-side bundling
- **TypeScript** for type safety across frontend and backend
- **PostCSS** with Autoprefixer for CSS processing
- **Vite plugins** for runtime error handling and GLSL shader support

### Audio System
- **HTML5 Audio API** for background music and sound effects
- **Dynamic audio loading** with fallback handling
- **Mute functionality** with persistent state management

### UI Framework
- **Radix UI primitives** for accessible components (dialogs, buttons, progress bars)
- **Lucide React** for consistent iconography
- **Class Variance Authority** for component variant management
- **CLSX/Tailwind Merge** for conditional styling