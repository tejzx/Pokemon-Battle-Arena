interface PokemonStats {
  hp: number;
  attack: number;
  defense: number;
  speed: number;
}

interface Pokemon {
  stats: PokemonStats;
  types: string[];
}

interface Move {
  type: string;
  power: number;
  accuracy: number;
}

// Type effectiveness chart
const typeEffectiveness: { [key: string]: { [key: string]: number } } = {
  normal: { rock: 0.5, ghost: 0, steel: 0.5 },
  fire: { fire: 0.5, water: 0.5, grass: 2, ice: 2, bug: 2, rock: 0.5, dragon: 0.5, steel: 2 },
  water: { fire: 2, water: 0.5, grass: 0.5, ground: 2, rock: 2, dragon: 0.5 },
  electric: { water: 2, electric: 0.5, grass: 0.5, ground: 0, flying: 2, dragon: 0.5 },
  grass: { fire: 0.5, water: 2, grass: 0.5, poison: 0.5, flying: 0.5, bug: 0.5, rock: 2, ground: 2, dragon: 0.5, steel: 0.5 },
  ice: { fire: 0.5, water: 0.5, grass: 2, ice: 0.5, ground: 2, flying: 2, dragon: 2, steel: 0.5 },
  fighting: { normal: 2, ice: 2, poison: 0.5, flying: 0.5, psychic: 0.5, bug: 0.5, rock: 2, ghost: 0, dark: 2, steel: 2 },
  poison: { grass: 2, poison: 0.5, ground: 0.5, rock: 0.5, ghost: 0.5, steel: 0 },
  ground: { fire: 2, electric: 2, grass: 0.5, poison: 2, flying: 0, bug: 0.5, rock: 2, steel: 2 },
  flying: { electric: 0.5, grass: 2, ice: 0.5, fighting: 2, bug: 2, rock: 0.5, steel: 0.5 },
  psychic: { fighting: 2, poison: 2, psychic: 0.5, dark: 0, steel: 0.5 },
  bug: { fire: 0.5, grass: 2, fighting: 0.5, poison: 0.5, flying: 0.5, psychic: 2, ghost: 0.5, dark: 2, steel: 0.5 },
  rock: { fire: 2, ice: 2, fighting: 0.5, ground: 0.5, flying: 2, bug: 2, steel: 0.5 },
  ghost: { normal: 0, psychic: 2, ghost: 2, dark: 0.5, steel: 0.5 },
  dragon: { dragon: 2, steel: 0.5 },
  dark: { fighting: 0.5, psychic: 2, ghost: 2, dark: 0.5, steel: 0.5 },
  steel: { fire: 0.5, water: 0.5, electric: 0.5, ice: 2, rock: 2, steel: 0.5 }
};

export function getEffectiveness(attackType: string, defenderTypes: string[]): number {
  let effectiveness = 1;
  
  for (const defenderType of defenderTypes) {
    const typeChart = typeEffectiveness[attackType.toLowerCase()];
    if (typeChart && typeChart[defenderType.toLowerCase()] !== undefined) {
      effectiveness *= typeChart[defenderType.toLowerCase()];
    }
  }
  
  return effectiveness;
}

export function calculateDamage(
  attacker: Pokemon,
  defender: Pokemon,
  move: Move
): number {
  // Status moves don't deal damage
  if (move.power === 0) {
    return 0;
  }

  // Check if attack hits
  const hitChance = Math.random() * 100;
  if (hitChance > move.accuracy) {
    return 0; // Miss
  }

  // Enhanced damage calculation for longer battles
  const level = 50; // Assume all Pokémon are level 50
  let baseDamage = ((2 * level / 5 + 2) * move.power * attacker.stats.attack / defender.stats.defense / 50 + 2) * 0.6;
  
  // Apply type effectiveness
  const effectiveness = getEffectiveness(move.type, defender.types);
  
  // Critical hit chance (6.25% chance)
  let isCritical = Math.random() < 0.0625;
  if (isCritical) {
    baseDamage *= 1.5;
  }
  
  // Random factor (85-100%)
  const randomFactor = (Math.random() * 0.15 + 0.85);
  
  // STAB (Same Type Attack Bonus) - 1.5x if attacker has same type as move
  const stab = attacker.types.includes(move.type.toLowerCase()) ? 1.5 : 1;
  
  const finalDamage = Math.floor(baseDamage * effectiveness * randomFactor * stab);
  
  return Math.max(move.power > 0 ? 1 : 0, finalDamage);
}

export function calculateSpeed(pokemon: Pokemon): number {
  // Simple speed calculation
  return pokemon.stats.speed;
}

export function isKnockedOut(pokemon: Pokemon & { currentHp: number }): boolean {
  return pokemon.currentHp <= 0;
}

export function getRandomMove(moves: Move[]): Move {
  return moves[Math.floor(Math.random() * moves.length)];
}

// AI logic for enemy Pokémon
export function getAIMove(enemyPokemon: Pokemon, playerPokemon: Pokemon, availableMoves: Move[]): Move {
  // Simple AI: prefer moves that are super effective
  const effectiveMoves = availableMoves.filter(move => 
    getEffectiveness(move.type, playerPokemon.types) > 1
  );
  
  if (effectiveMoves.length > 0) {
    return effectiveMoves[Math.floor(Math.random() * effectiveMoves.length)];
  }
  
  // Otherwise, use highest power move
  const sortedMoves = [...availableMoves].sort((a, b) => b.power - a.power);
  return sortedMoves[0];
}
