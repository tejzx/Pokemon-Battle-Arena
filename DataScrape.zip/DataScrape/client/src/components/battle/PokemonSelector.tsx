import { useState, useEffect } from "react";
import { useKeyboardControls } from "@react-three/drei";
import { useBattle } from "../../lib/stores/useBattle";
import { usePokemon } from "../../lib/stores/usePokemon";
import { useGame } from "../../lib/stores/useGame";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";

export function PokemonSelector() {
  const { availablePokemon, isLoading } = usePokemon();
  const { selectPlayerPokemon, selectEnemyPokemon, startBattle } = useBattle();
  const { trainerName } = useGame();
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [playerSelected, setPlayerSelected] = useState(false);

  // Keyboard controls
  const [, getControls] = useKeyboardControls();

  useEffect(() => {
    let lastKeyTime = 0;
    
    const handleKeyPress = (event: KeyboardEvent) => {
      if (playerSelected) return; // Don't handle keys after selection
      
      const now = Date.now();
      if (now - lastKeyTime < 150) return; // Reduced debounce for better responsiveness
      lastKeyTime = now;
      
      // Handle scrolling through Pokemon
      if ((event.code === 'ArrowUp' || event.code === 'KeyW') && availablePokemon.length > 0) {
        event.preventDefault();
        event.stopPropagation();
        setSelectedIndex(prev => {
          const newIndex = prev - 1;
          return newIndex < 0 ? availablePokemon.length - 1 : newIndex; // Wrap around
        });
        console.log('Scroll up, new index:', selectedIndex);
      } else if ((event.code === 'ArrowDown' || event.code === 'KeyS') && availablePokemon.length > 0) {
        event.preventDefault();
        event.stopPropagation();
        setSelectedIndex(prev => {
          const newIndex = prev + 1;
          return newIndex >= availablePokemon.length ? 0 : newIndex; // Wrap around
        });
        console.log('Scroll down, new index:', selectedIndex);
      } else if ((event.code === 'Enter' || event.code === 'Space') && availablePokemon[selectedIndex]) {
        event.preventDefault();
        event.stopPropagation();
        const selected = availablePokemon[selectedIndex];
        if (!playerSelected && selected) {
          const playerPokemon = { ...selected, currentHp: selected.stats.hp };
          selectPlayerPokemon(playerPokemon);
          setPlayerSelected(true);
          
          const enemyIndex = Math.floor(Math.random() * availablePokemon.length);
          const enemyPokemon = { ...availablePokemon[enemyIndex], currentHp: availablePokemon[enemyIndex].stats.hp };
          selectEnemyPokemon(enemyPokemon);
          
          setTimeout(() => startBattle(), 1000);
        }
      }
    };

    // Add mouse wheel support
    const handleWheel = (event: WheelEvent) => {
      if (playerSelected) return;
      event.preventDefault();
      
      if (event.deltaY > 0) {
        // Scroll down
        setSelectedIndex(prev => prev >= availablePokemon.length - 1 ? 0 : prev + 1);
      } else {
        // Scroll up
        setSelectedIndex(prev => prev <= 0 ? availablePokemon.length - 1 : prev - 1);
      }
    };

    window.addEventListener('keydown', handleKeyPress, { capture: true });
    window.addEventListener('wheel', handleWheel, { passive: false });
    
    return () => {
      window.removeEventListener('keydown', handleKeyPress, { capture: true });
      window.removeEventListener('wheel', handleWheel);
    };
  }, [selectedIndex, availablePokemon, playerSelected]);

  const handleSelect = () => {
    const selected = availablePokemon[selectedIndex];
    if (!playerSelected && selected) {
      // Add currentHp to the selected Pokémon
      const playerPokemon = { ...selected, currentHp: selected.stats.hp };
      selectPlayerPokemon(playerPokemon);
      setPlayerSelected(true);
      
      // Auto-select enemy (AI will choose randomly)
      const enemyIndex = Math.floor(Math.random() * availablePokemon.length);
      const enemyPokemon = { ...availablePokemon[enemyIndex], currentHp: availablePokemon[enemyIndex].stats.hp };
      selectEnemyPokemon(enemyPokemon);
      
      // Start battle after short delay
      setTimeout(() => {
        console.log('Starting battle with player:', playerPokemon, 'enemy:', enemyPokemon);
        startBattle();
      }, 1000);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-400 to-blue-600 flex items-center justify-center">
        <Card className="bg-white text-black">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-center">Loading Pokémon...</h2>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 to-blue-600 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-white text-black mb-6">
          <CardContent className="p-6 text-center">
            <div className="mb-4">
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-full font-semibold">
                <span className="text-2xl">👨‍🎓</span>
                <span>Trainer {trainerName}</span>
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-2">Pokémon Battle Arena</h1>
            <p className="text-lg">
              {!playerSelected ? "Choose your Pokémon partner!" : "Preparing for epic battle..."}
            </p>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availablePokemon.map((pokemon, index) => (
            <Card
              key={pokemon.id}
              className={`cursor-pointer transition-all duration-200 ${
                selectedIndex === index
                  ? "bg-yellow-200 border-yellow-400 border-2 scale-105"
                  : "bg-white hover:bg-gray-50"
              } text-black`}
              onClick={() => !playerSelected && setSelectedIndex(index)}
            >
              <CardContent className="p-4">
                <div className="text-center">
                  {/* Pokémon Image */}
                  <div className="w-24 h-24 mx-auto mb-3 bg-gray-100 rounded-full overflow-hidden flex items-center justify-center">
                    <img 
                      src={pokemon.imageUrl} 
                      alt={pokemon.name}
                      className="w-20 h-20 object-contain"
                      onError={(e) => {
                        // Fallback to a colored circle if image fails
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling?.classList.remove('hidden');
                      }}
                    />
                    <div className="w-20 h-20 rounded-full hidden" style={{
                      backgroundColor: pokemon.types[0] === 'fire' ? '#FF6666' : 
                                     pokemon.types[0] === 'water' ? '#6666FF' : 
                                     pokemon.types[0] === 'grass' ? '#66FF66' : 
                                     pokemon.types[0] === 'electric' ? '#FFFF66' : 
                                     pokemon.types[0] === 'psychic' ? '#FF66FF' : '#CCCCCC'
                    }}></div>
                  </div>

                  <h3 className="text-xl font-bold mb-2">{pokemon.name}</h3>
                  
                  <div className="flex justify-center gap-1 mb-3">
                    {pokemon.types.map((type) => (
                      <Badge key={type} variant="secondary" className="text-xs">
                        {type}
                      </Badge>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <div className="font-semibold">HP</div>
                      <div>{pokemon.stats.hp}</div>
                    </div>
                    <div>
                      <div className="font-semibold">Attack</div>
                      <div>{pokemon.stats.attack}</div>
                    </div>
                    <div>
                      <div className="font-semibold">Defense</div>
                      <div>{pokemon.stats.defense}</div>
                    </div>
                    <div>
                      <div className="font-semibold">Speed</div>
                      <div>{pokemon.stats.speed}</div>
                    </div>
                  </div>

                  <div className="mt-3">
                    <div className="font-semibold text-sm mb-1">Moves:</div>
                    <div className="text-xs space-y-1">
                      {pokemon.moves.slice(0, 2).map((move) => (
                        <div key={move.name} className="bg-gray-100 p-1 rounded">
                          {move.name} ({move.type})
                        </div>
                      ))}
                    </div>
                  </div>

                  {selectedIndex === index && !playerSelected && (
                    <Button onClick={handleSelect} className="mt-3 w-full">
                      Select {pokemon.name}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-white text-black mt-6">
          <CardContent className="p-4 text-center text-sm">
            <p>Use ↑↓ arrows or W/S keys to navigate • Enter/Space to select</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
