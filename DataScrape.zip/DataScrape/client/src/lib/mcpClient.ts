import { Pokemon } from './pokemonData';

class MCPClient {
  private baseUrl: string;
  private apiKey: string;

  constructor() {
    this.baseUrl = import.meta.env.VITE_MCP_SERVER_URL || 'http://localhost:8000';
    this.apiKey = import.meta.env.VITE_MCP_API_KEY || 'default_key';
  }

  async getPokemonList(): Promise<Pokemon[]> {
    try {
      // Try to fetch from the local server first (MCP simulation)
      const response = await fetch('/api/pokemon', {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return this.transformPokemonData(data);
    } catch (error) {
      console.error('Failed to fetch Pokémon from MCP server:', error);
      throw error;
    }
  }

  async getPokemonById(id: number): Promise<Pokemon | null> {
    try {
      const response = await fetch(`${this.baseUrl}/api/pokemon/${id}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        if (response.status === 404) {
          return null;
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return this.transformSinglePokemon(data);
    } catch (error) {
      console.error(`Failed to fetch Pokémon ${id} from MCP server:`, error);
      throw error;
    }
  }

  async getPokemonMoves(pokemonId: number): Promise<any[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/pokemon/${pokemonId}/moves`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error(`Failed to fetch moves for Pokémon ${pokemonId}:`, error);
      throw error;
    }
  }

  private transformPokemonData(rawData: any[]): Pokemon[] {
    return rawData.map(pokemon => this.transformSinglePokemon(pokemon));
  }

  private transformSinglePokemon(rawPokemon: any): Pokemon {
    return {
      id: rawPokemon.id,
      name: rawPokemon.name || 'Unknown',
      types: rawPokemon.types || ['normal'],
      imageUrl: rawPokemon.imageUrl || `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${rawPokemon.id || 1}.png`,
      stats: {
        hp: rawPokemon.stats?.hp || 50,
        attack: rawPokemon.stats?.attack || 50,
        defense: rawPokemon.stats?.defense || 50,
        speed: rawPokemon.stats?.speed || 50,
      },
      moves: rawPokemon.moves?.map((move: any) => ({
        name: move.name || 'Tackle',
        type: move.type || 'normal',
        power: move.power || 40,
        accuracy: move.accuracy || 100,
        pp: move.pp || 35,
      })) || [
        { name: 'Tackle', type: 'normal', power: 40, accuracy: 100, pp: 35 },
        { name: 'Growl', type: 'normal', power: 0, accuracy: 100, pp: 40 },
      ]
    };
  }

  // Test connection to MCP server
  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/health`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
        },
      });
      return response.ok;
    } catch (error) {
      console.error('MCP server connection test failed:', error);
      return false;
    }
  }
}

export const mcpClient = new MCPClient();
