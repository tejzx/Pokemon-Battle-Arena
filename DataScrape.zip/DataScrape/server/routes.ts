import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for MCP integration
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Mock Pokémon API endpoints for MCP integration
  app.get("/api/pokemon", (req, res) => {
    const mockPokemon = [
      {
        id: 25,
        name: "Pikachu",
        types: ["electric"],
        imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png",
        stats: { hp: 35, attack: 55, defense: 40, speed: 90 },
        moves: [
          { name: "Thunderbolt", type: "electric", power: 90, accuracy: 100, pp: 15 },
          { name: "Quick Attack", type: "normal", power: 40, accuracy: 100, pp: 30 },
          { name: "Iron Tail", type: "steel", power: 100, accuracy: 75, pp: 15 },
          { name: "Electro Ball", type: "electric", power: 60, accuracy: 100, pp: 10 }
        ]
      },
      {
        id: 4,
        name: "Charmander",
        types: ["fire"],
        imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png",
        stats: { hp: 39, attack: 52, defense: 43, speed: 65 },
        moves: [
          { name: "Flamethrower", type: "fire", power: 90, accuracy: 100, pp: 15 },
          { name: "Scratch", type: "normal", power: 40, accuracy: 100, pp: 35 },
          { name: "Dragon Pulse", type: "dragon", power: 85, accuracy: 100, pp: 10 },
          { name: "Fire Punch", type: "fire", power: 75, accuracy: 100, pp: 15 }
        ]
      },
      {
        id: 7,
        name: "Squirtle",
        types: ["water"],
        imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png",
        stats: { hp: 44, attack: 48, defense: 65, speed: 43 },
        moves: [
          { name: "Water Gun", type: "water", power: 40, accuracy: 100, pp: 25 },
          { name: "Bubble Beam", type: "water", power: 65, accuracy: 100, pp: 20 },
          { name: "Ice Beam", type: "ice", power: 90, accuracy: 100, pp: 10 },
          { name: "Tackle", type: "normal", power: 40, accuracy: 100, pp: 35 }
        ]
      },
      {
        id: 1,
        name: "Bulbasaur",
        types: ["grass", "poison"],
        imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png",
        stats: { hp: 45, attack: 49, defense: 49, speed: 45 },
        moves: [
          { name: "Vine Whip", type: "grass", power: 45, accuracy: 100, pp: 25 },
          { name: "Razor Leaf", type: "grass", power: 55, accuracy: 95, pp: 25 },
          { name: "Sludge Bomb", type: "poison", power: 90, accuracy: 100, pp: 10 },
          { name: "Tackle", type: "normal", power: 40, accuracy: 100, pp: 35 }
        ]
      },
      {
        id: 6,
        name: "Charizard",
        types: ["fire", "flying"],
        imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/6.png",
        stats: { hp: 78, attack: 84, defense: 78, speed: 100 },
        moves: [
          { name: "Fire Blast", type: "fire", power: 110, accuracy: 85, pp: 5 },
          { name: "Air Slash", type: "flying", power: 75, accuracy: 95, pp: 15 },
          { name: "Dragon Claw", type: "dragon", power: 80, accuracy: 100, pp: 15 },
          { name: "Solar Beam", type: "grass", power: 120, accuracy: 100, pp: 10 }
        ]
      },
      {
        id: 150,
        name: "Mewtwo",
        types: ["psychic"],
        imageUrl: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png",
        stats: { hp: 106, attack: 110, defense: 90, speed: 130 },
        moves: [
          { name: "Psychic", type: "psychic", power: 90, accuracy: 100, pp: 10 },
          { name: "Shadow Ball", type: "ghost", power: 80, accuracy: 100, pp: 15 },
          { name: "Aura Sphere", type: "fighting", power: 80, accuracy: 100, pp: 20 },
          { name: "Psystrike", type: "psychic", power: 100, accuracy: 100, pp: 10 }
        ]
      }
    ];

    res.json(mockPokemon);
  });

  app.get("/api/pokemon/:id", (req, res) => {
    const id = parseInt(req.params.id);
    
    // Mock individual Pokémon data
    const mockPokemon = {
      25: {
        id: 25,
        name: "Pikachu",
        types: ["electric"],
        stats: { hp: 35, attack: 55, defense: 40, speed: 90 },
        moves: [
          { name: "Thunderbolt", type: "electric", power: 90, accuracy: 100, pp: 15 },
          { name: "Quick Attack", type: "normal", power: 40, accuracy: 100, pp: 30 }
        ]
      }
    };

    const pokemon = mockPokemon[id as keyof typeof mockPokemon];
    if (pokemon) {
      res.json(pokemon);
    } else {
      res.status(404).json({ error: "Pokémon not found" });
    }
  });

  app.get("/api/pokemon/:id/moves", (req, res) => {
    const id = parseInt(req.params.id);
    
    // Mock moves data
    const moves = [
      { name: "Tackle", type: "normal", power: 40, accuracy: 100, pp: 35 },
      { name: "Growl", type: "normal", power: 0, accuracy: 100, pp: 40 },
    ];

    res.json(moves);
  });

  // Battle simulation endpoint
  app.post("/api/battle/simulate", (req, res) => {
    const { playerPokemon, enemyPokemon, playerMove } = req.body;
    
    // Simple battle simulation
    const damage = Math.floor(Math.random() * 50) + 10;
    const effectiveness = Math.random() > 0.5 ? "normal" : "super";
    
    res.json({
      damage,
      effectiveness,
      winner: Math.random() > 0.5 ? "player" : "enemy"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
