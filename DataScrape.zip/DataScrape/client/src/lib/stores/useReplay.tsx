import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

interface BattleAction {
  id: string;
  timestamp: number;
  type: 'attack' | 'switch' | 'effect';
  playerName: string;
  pokemonName: string;
  moveName?: string;
  damage?: number;
  effectiveness?: number;
  description: string;
}

interface BattleReplay {
  id: string;
  title: string;
  date: string;
  playerName: string;
  enemyName: string;
  winner: string;
  duration: number;
  actions: BattleAction[];
  highlights: BattleAction[];
  thumbnail?: string;
}

interface ReplayState {
  currentRecording: BattleAction[];
  savedReplays: BattleReplay[];
  isRecording: boolean;
  isPlaying: boolean;
  playbackSpeed: number;
  currentPlayback: BattleReplay | null;
  
  // Actions
  startRecording: (playerName: string, enemyName: string) => void;
  stopRecording: () => void;
  recordAction: (action: Omit<BattleAction, 'id' | 'timestamp'>) => void;
  saveReplay: (title: string, winner: string, duration: number) => void;
  loadReplay: (replayId: string) => void;
  deleteReplay: (replayId: string) => void;
  setPlaybackSpeed: (speed: number) => void;
  addHighlight: (actionId: string) => void;
  removeHighlight: (actionId: string) => void;
}

export const useReplay = create<ReplayState>()(
  subscribeWithSelector((set, get) => ({
    currentRecording: [],
    savedReplays: [],
    isRecording: false,
    isPlaying: false,
    playbackSpeed: 1,
    currentPlayback: null,
    
    startRecording: (playerName, enemyName) => {
      set({ 
        isRecording: true, 
        currentRecording: [],
      });
      
      // Record battle start
      get().recordAction({
        type: 'effect',
        playerName,
        pokemonName: '',
        description: `Battle started: ${playerName} vs ${enemyName}`
      });
    },
    
    stopRecording: () => {
      set({ isRecording: false });
    },
    
    recordAction: (action) => {
      if (!get().isRecording) return;
      
      const newAction: BattleAction = {
        ...action,
        id: Math.random().toString(36),
        timestamp: Date.now()
      };
      
      set(state => ({
        currentRecording: [...state.currentRecording, newAction]
      }));
    },
    
    saveReplay: (title, winner, duration) => {
      const { currentRecording } = get();
      if (currentRecording.length === 0) return;
      
      const replay: BattleReplay = {
        id: Math.random().toString(36),
        title,
        date: new Date().toISOString(),
        playerName: currentRecording[0]?.playerName || 'Player',
        enemyName: 'Enemy', // Extract from first action if available
        winner,
        duration,
        actions: currentRecording,
        highlights: []
      };
      
      set(state => ({
        savedReplays: [...state.savedReplays, replay],
        currentRecording: [],
        isRecording: false
      }));
    },
    
    loadReplay: (replayId) => {
      const replay = get().savedReplays.find(r => r.id === replayId);
      if (replay) {
        set({ currentPlayback: replay, isPlaying: true });
      }
    },
    
    deleteReplay: (replayId) => {
      set(state => ({
        savedReplays: state.savedReplays.filter(r => r.id !== replayId)
      }));
    },
    
    setPlaybackSpeed: (speed) => {
      set({ playbackSpeed: speed });
    },
    
    addHighlight: (actionId) => {
      const { currentPlayback } = get();
      if (!currentPlayback) return;
      
      const action = currentPlayback.actions.find(a => a.id === actionId);
      if (action && !currentPlayback.highlights.includes(action)) {
        set(state => ({
          currentPlayback: state.currentPlayback ? {
            ...state.currentPlayback,
            highlights: [...state.currentPlayback.highlights, action]
          } : null
        }));
      }
    },
    
    removeHighlight: (actionId) => {
      set(state => ({
        currentPlayback: state.currentPlayback ? {
          ...state.currentPlayback,
          highlights: state.currentPlayback.highlights.filter(h => h.id !== actionId)
        } : null
      }));
    }
  }))
);