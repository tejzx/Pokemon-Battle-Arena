import { useEffect, useRef } from 'react';
import { useBattle } from '../../lib/stores/useBattle';
import { useAudio } from '../../lib/stores/useAudio';

export function PokemonThemeMusic() {
  const { battlePhase, playerPokemon, enemyPokemon, isAttacking } = useBattle();
  const { isMuted } = useAudio();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const battleMusicRef = useRef<HTMLAudioElement | null>(null);

  // Pokemon theme songs (using public domain or royalty-free alternatives)
  const getThemeMusic = (pokemon: any) => {
    if (!pokemon) return null;
    
    // Map Pokemon types to musical themes
    const themes: { [key: string]: string } = {
      electric: '/audio/electric_theme.mp3',
      fire: '/audio/fire_theme.mp3',
      water: '/audio/water_theme.mp3',
      grass: '/audio/grass_theme.mp3',
      psychic: '/audio/psychic_theme.mp3',
      dragon: '/audio/dragon_theme.mp3',
      ice: '/audio/ice_theme.mp3',
      fighting: '/audio/fighting_theme.mp3',
      default: '/audio/pokemon_battle_theme.mp3'
    };

    return themes[pokemon.types[0]] || themes.default;
  };

  // Create audio elements with error handling
  const createAudioElement = (src: string, loop: boolean = true, volume: number = 0.3) => {
    const audio = new Audio();
    audio.src = src;
    audio.loop = loop;
    audio.volume = volume;
    audio.preload = 'auto';
    
    // Handle loading errors gracefully
    audio.addEventListener('error', (e) => {
      console.log('Audio file not found, using silence:', src);
      // Continue without audio rather than breaking the game
    });
    
    return audio;
  };

  // Initialize battle music
  useEffect(() => {
    if (battlePhase === 'battle' && !isMuted) {
      // Stop any existing music
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (battleMusicRef.current) {
        battleMusicRef.current.pause();
        battleMusicRef.current = null;
      }

      // Determine which theme to play based on Pokemon types
      let themeMusic = '/audio/pokemon_battle_theme.mp3'; // Default battle theme
      
      if (playerPokemon && enemyPokemon) {
        // If both Pokemon have same primary type, use that theme
        if (playerPokemon.types[0] === enemyPokemon.types[0]) {
          themeMusic = getThemeMusic(playerPokemon) || themeMusic;
        } else {
          // Mix of types - use default epic battle theme
          themeMusic = '/audio/pokemon_epic_battle.mp3';
        }
      } else if (playerPokemon) {
        themeMusic = getThemeMusic(playerPokemon) || themeMusic;
      }

      // Start battle music
      battleMusicRef.current = createAudioElement(themeMusic, true, 0.4);
      battleMusicRef.current.play().catch(e => {
        console.log('Battle music autoplay blocked or file missing');
      });

      // Add intensity during attacks
      if (isAttacking) {
        battleMusicRef.current.playbackRate = 1.1; // Speed up slightly
        battleMusicRef.current.volume = 0.5; // Increase volume
      }
    }

    return () => {
      // Cleanup
      if (battleMusicRef.current) {
        battleMusicRef.current.pause();
        battleMusicRef.current = null;
      }
    };
  }, [battlePhase, playerPokemon, enemyPokemon, isMuted]);

  // React to attacks with musical stings
  useEffect(() => {
    if (isAttacking && !isMuted && battleMusicRef.current) {
      // Increase intensity during attacks
      battleMusicRef.current.volume = Math.min(0.6, battleMusicRef.current.volume + 0.1);
      battleMusicRef.current.playbackRate = 1.15;
      
      // Reset after attack
      setTimeout(() => {
        if (battleMusicRef.current) {
          battleMusicRef.current.volume = 0.4;
          battleMusicRef.current.playbackRate = 1.0;
        }
      }, 1500);
    }
  }, [isAttacking, isMuted]);

  // Handle mute/unmute
  useEffect(() => {
    if (battleMusicRef.current) {
      if (isMuted) {
        battleMusicRef.current.volume = 0;
      } else {
        battleMusicRef.current.volume = isAttacking ? 0.5 : 0.4;
      }
    }
  }, [isMuted, isAttacking]);

  // Play victory/defeat themes
  useEffect(() => {
    if (battlePhase === 'victory' && !isMuted) {
      if (battleMusicRef.current) {
        battleMusicRef.current.pause();
      }
      
      const victoryTheme = createAudioElement('/audio/pokemon_victory.mp3', false, 0.6);
      audioRef.current = victoryTheme;
      victoryTheme.play().catch(e => console.log('Victory music blocked or missing'));
    }
  }, [battlePhase, isMuted]);

  return null; // This component only handles audio, no visual rendering
}