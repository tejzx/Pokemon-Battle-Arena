import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { useBattle } from "../../lib/stores/useBattle";
import * as THREE from "three";

// Helper function to get attack color based on type
const getAttackColor = (type: string) => {
  const colors: { [key: string]: THREE.Color } = {
    fire: new THREE.Color(1, 0.4, 0),
    water: new THREE.Color(0, 0.4, 1),
    grass: new THREE.Color(0.4, 1, 0),
    electric: new THREE.Color(1, 1, 0),
    psychic: new THREE.Color(1, 0, 1),
    ice: new THREE.Color(0.5, 0.8, 1),
    normal: new THREE.Color(0.8, 0.8, 0.8),
  };
  return colors[type.toLowerCase()] || colors.normal;
};

export function AttackEffects() {
  const { lastAttack, isAttacking } = useBattle();
  const particlesRef = useRef<THREE.Points>(null);
  const timeRef = useRef(0);

  // Create particle system
  const particleSystem = useMemo(() => {
    const particleCount = 100;
    const particles = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      // Random positions
      positions[i * 3] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 1] = Math.random() * 5;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;

      // Colors based on attack type
      const color = getAttackColor(lastAttack?.type || 'normal');
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }

    particles.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particles.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    return particles;
  }, [lastAttack]);

  useFrame((state, delta) => {
    if (!isAttacking || !particlesRef.current) return;

    timeRef.current += delta;
    const positions = particlesRef.current.geometry.attributes.position;

    for (let i = 0; i < positions.count; i++) {
      // Animate particles
      const x = positions.getX(i);
      const y = positions.getY(i);
      const z = positions.getZ(i);

      // Move particles based on attack type
      if (lastAttack?.type === 'fire') {
        positions.setY(i, y + delta * 2);
        positions.setX(i, x + Math.sin(timeRef.current + i) * delta);
      } else if (lastAttack?.type === 'water') {
        positions.setY(i, y - delta * 3);
        positions.setZ(i, z + Math.cos(timeRef.current + i) * delta);
      } else if (lastAttack?.type === 'electric') {
        positions.setX(i, x + Math.sin(timeRef.current * 10 + i) * delta * 5);
        positions.setY(i, y + Math.cos(timeRef.current * 10 + i) * delta * 5);
      } else {
        // Default explosion effect
        positions.setX(i, x + Math.sin(timeRef.current + i) * delta * 3);
        positions.setY(i, y + Math.cos(timeRef.current + i) * delta * 3);
        positions.setZ(i, z + Math.sin(timeRef.current * 2 + i) * delta * 2);
      }
    }

    positions.needsUpdate = true;

    // Fade out effect
    const material = particlesRef.current.material as THREE.PointsMaterial;
    material.opacity = Math.max(0, 1 - timeRef.current / 2);
  });

  if (!isAttacking) {
    timeRef.current = 0;
    return null;
  }

  return (
    <points ref={particlesRef} geometry={particleSystem}>
      <pointsMaterial
        size={0.1}
        vertexColors
        transparent
        opacity={1}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}
