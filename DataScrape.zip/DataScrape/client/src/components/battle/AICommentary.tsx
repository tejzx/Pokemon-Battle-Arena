import { useState, useEffect } from 'react';
import { useBattle } from '../../lib/stores/useBattle';
import { Card, CardContent } from '../ui/card';
import { motion, AnimatePresence } from 'framer-motion';

export function AICommentary() {
  const { battleLog, playerPokemon, enemyPokemon, isAttacking, lastAttack, currentTurn } = useBattle();
  const [currentCommentary, setCurrentCommentary] = useState('');
  const [showCommentary, setShowCommentary] = useState(false);

  // Commentary templates based on battle situations
  const getCommentary = (situation: string, pokemon1?: any, pokemon2?: any, move?: any) => {
    const commentaries: { [key: string]: string[] } = {
      battleStart: [
        `What an incredible matchup! ${pokemon1?.name} versus ${pokemon2?.name}!`,
        `The crowd is going wild! This battle is about to be legendary!`,
        `Both trainers look determined! Who will emerge victorious?`,
        `The tension is electric! These Pokémon are ready to give it their all!`
      ],
      superEffective: [
        `INCREDIBLE! That attack was super effective!`,
        `What a devastating blow! The crowd is on their feet!`,
        `Amazing strategy! That type advantage really paid off!`,
        `Unbelievable power! That's how you win battles!`
      ],
      notVeryEffective: [
        `Oh no! That attack didn't have much impact!`,
        `The defense held strong! What a resilient Pokémon!`,
        `That type matchup isn't working out as planned!`,
        `Sometimes you need to switch up your strategy!`
      ],
      criticalHit: [
        `CRITICAL HIT! What an extraordinary display of power!`,
        `That was perfectly executed! A critical strike!`,
        `The RNG gods are smiling! What a critical moment!`,
        `Incredible timing! That critical hit changes everything!`
      ],
      lowHP: [
        `${pokemon1?.name} is hanging on by a thread! This is intense!`,
        `What determination! ${pokemon1?.name} refuses to give up!`,
        `One more hit could end this battle! The suspense is killing me!`,
        `Both Pokémon are giving everything they've got!`
      ],
      electricAttack: [
        `Lightning strikes! The electrical energy is crackling through the arena!`,
        `What a shocking display of power! The voltage is off the charts!`,
        `Thunder and lightning! This electric attack is electrifying!`
      ],
      fireAttack: [
        `The arena is heating up! Those flames are scorching hot!`,
        `Fire blazes across the battlefield! What incredible heat!`,
        `Burning bright! That fire attack is absolutely sizzling!`
      ],
      waterAttack: [
        `Tsunami incoming! The water pressure is incredible!`,
        `Splash zone activated! What a powerful water display!`,
        `Making waves! That aquatic assault is devastating!`
      ],
      psychicAttack: [
        `Mind over matter! The psychic energy is bending reality!`,
        `Telepathic terror! This mental assault is otherworldly!`,
        `The power of the mind! Psychic forces are at work!`
      ]
    };

    const options = commentaries[situation] || [];
    return options[Math.floor(Math.random() * options.length)] || '';
  };

  // React to battle events
  useEffect(() => {
    if (battleLog.length > 0) {
      const latestLog = battleLog[battleLog.length - 1];
      let commentary = '';
      
      if (latestLog.includes('Battle begins')) {
        commentary = getCommentary('battleStart', playerPokemon, enemyPokemon);
      } else if (latestLog.includes('super effective')) {
        commentary = getCommentary('superEffective');
      } else if (latestLog.includes('not very effective')) {
        commentary = getCommentary('notVeryEffective');
      } else if (latestLog.includes('critical')) {
        commentary = getCommentary('criticalHit');
      } else if (lastAttack) {
        // Type-specific commentary
        if (lastAttack.type === 'electric') {
          commentary = getCommentary('electricAttack');
        } else if (lastAttack.type === 'fire') {
          commentary = getCommentary('fireAttack');
        } else if (lastAttack.type === 'water') {
          commentary = getCommentary('waterAttack');
        } else if (lastAttack.type === 'psychic') {
          commentary = getCommentary('psychicAttack');
        }
      }

      if (commentary) {
        setCurrentCommentary(commentary);
        setShowCommentary(true);
        
        // Hide commentary after 4 seconds
        setTimeout(() => {
          setShowCommentary(false);
        }, 4000);
      }
    }
  }, [battleLog, lastAttack, playerPokemon, enemyPokemon]);

  // Check for low HP situations
  useEffect(() => {
    if (playerPokemon && playerPokemon.currentHp <= playerPokemon.stats.hp * 0.2) {
      const commentary = getCommentary('lowHP', playerPokemon);
      if (commentary && currentCommentary !== commentary) {
        setCurrentCommentary(commentary);
        setShowCommentary(true);
        setTimeout(() => setShowCommentary(false), 4000);
      }
    }
    if (enemyPokemon && enemyPokemon.currentHp <= enemyPokemon.stats.hp * 0.2) {
      const commentary = getCommentary('lowHP', enemyPokemon);
      if (commentary && currentCommentary !== commentary) {
        setCurrentCommentary(commentary);
        setShowCommentary(true);
        setTimeout(() => setShowCommentary(false), 4000);
      }
    }
  }, [playerPokemon?.currentHp, enemyPokemon?.currentHp, currentCommentary]);

  return (
    <AnimatePresence>
      {showCommentary && currentCommentary && (
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -30, scale: 0.9 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 max-w-md"
        >
          <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-2xl border-2 border-yellow-400">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center">
                  <span className="text-2xl">🎙️</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-sm text-yellow-200">AI COMMENTATOR</h3>
                  <p className="text-lg font-semibold leading-tight">
                    {currentCommentary}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}