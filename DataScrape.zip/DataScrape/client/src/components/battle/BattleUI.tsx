import { useState, useEffect } from "react";
import { useKeyboardControls } from "@react-three/drei";
import { useBattle } from "../../lib/stores/useBattle";
import { useGame } from "../../lib/stores/useGame";
import { useAudio } from "../../lib/stores/useAudio";
import { Card, CardContent } from "../ui/card";
import { Button } from "../ui/button";
import { Progress } from "../ui/progress";

export function BattleUI() {
  const { 
    playerPokemon, 
    enemyPokemon, 
    currentTurn, 
    battlePhase,
    battleLog,
    executeAttack,
    switchToEnemyTurn,
    endBattle,
    playerAttackCount,
    playerDefenseCount,
    enemyAttackCount,
    enemyDefenseCount,
    canEndBattle
  } = useBattle();

  const { playHit, toggleMute, isMuted } = useAudio();
  const [selectedMove, setSelectedMove] = useState(0);
  const [showMoves, setShowMoves] = useState(false);
  
  console.log('BattleUI render:', { 
    battlePhase, 
    currentTurn, 
    playerPokemon: playerPokemon?.name,
    enemyPokemon: enemyPokemon?.name,
    playerAttackCount,
    playerDefenseCount,
    enemyAttackCount,
    enemyDefenseCount,
    canEndBattle
  });

  // Keyboard controls
  const [, getControls] = useKeyboardControls();

  useEffect(() => {
    const handleKeyPress = () => {
      const controls = getControls();
      
      if (currentTurn === 'player' && battlePhase === 'battle') {
        if (controls.select && !showMoves) {
          setShowMoves(true);
        } else if (controls.select && showMoves) {
          handleAttack(selectedMove);
        } else if (controls.cancel && showMoves) {
          setShowMoves(false);
        } else if (controls.up && showMoves) {
          setSelectedMove(Math.max(0, selectedMove - 1));
        } else if (controls.down && showMoves) {
          setSelectedMove(Math.min(3, selectedMove + 1));
        }
      }
    };

    const interval = setInterval(handleKeyPress, 100);
    return () => clearInterval(interval);
  }, [currentTurn, battlePhase, showMoves, selectedMove]);

  const handleAttack = (moveIndex: number) => {
    const move = playerPokemon?.moves[moveIndex];
    console.log('Player attacking with move:', move, 'at index:', moveIndex);
    if (move) {
      playHit();
      executeAttack(move, true);
      setShowMoves(false);
      
      // Switch to enemy turn after delay
      setTimeout(() => {
        console.log('Switching to enemy turn');
        switchToEnemyTurn();
      }, 2000);
    } else {
      console.error('No move found at index:', moveIndex, 'available moves:', playerPokemon?.moves);
    }
  };

  if (battlePhase === 'victory') {
    return (
      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <Card className="bg-white text-black p-8">
          <CardContent>
            <h2 className="text-3xl font-bold text-center mb-4">
              {(playerPokemon?.currentHp ?? 0) > 0 ? "Victory!" : "Defeat!"}
            </h2>
            <Button onClick={() => window.location.reload()} className="w-full">
              New Battle
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Battle Controls */}
      <div className="absolute bottom-4 left-4 right-4 pointer-events-auto">
        <Card className="bg-black bg-opacity-80 text-white">
          <CardContent className="p-4">
            {currentTurn === 'player' && !showMoves && (
              <div className="text-center">
                <p className="mb-2">What will {playerPokemon?.name} do?</p>
                <Button onClick={() => setShowMoves(true)} className="mr-2">
                  Attack
                </Button>
                <Button onClick={toggleMute} variant="outline">
                  {isMuted ? "Unmute" : "Mute"}
                </Button>
              </div>
            )}

            {showMoves && playerPokemon && (
              <div>
                <p className="mb-2">Select a move:</p>
                <div className="grid grid-cols-2 gap-2">
                  {playerPokemon.moves.map((move, index) => (
                    <Button
                      key={index}
                      onClick={() => handleAttack(index)}
                      variant={selectedMove === index ? "default" : "outline"}
                      className="text-left"
                    >
                      <div>
                        <div className="font-bold">{move.name}</div>
                        <div className="text-xs opacity-70">
                          {move.type} • {move.power > 0 ? `${move.power} PWR` : 'Status'} • {move.accuracy}% ACC
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {currentTurn === 'enemy' && (
              <div className="text-center">
                <p>Enemy {enemyPokemon?.name} is thinking...</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Pokemon Stats */}
      <div className="absolute top-4 left-4 pointer-events-auto">
        {playerPokemon && (
          <Card className="bg-black bg-opacity-80 text-white mb-2">
            <CardContent className="p-3">
              <div className="font-bold">{playerPokemon.name}</div>
              <Progress 
                value={(playerPokemon.currentHp / playerPokemon.stats.hp) * 100} 
                className="mt-1"
              />
              <div className="text-xs mt-1">
                {playerPokemon.currentHp}/{playerPokemon.stats.hp} HP
              </div>
              <div className="text-xs mt-1 space-y-0.5">
                <div>⚔️ {playerAttackCount}/5</div>
                <div>🛡️ {playerDefenseCount}/5</div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <div className="absolute top-4 right-4 pointer-events-auto">
        {enemyPokemon && (
          <Card className="bg-black bg-opacity-80 text-white mb-2">
            <CardContent className="p-3">
              <div className="font-bold">{enemyPokemon.name}</div>
              <Progress 
                value={(enemyPokemon.currentHp / enemyPokemon.stats.hp) * 100} 
                className="mt-1"
              />
              <div className="text-xs mt-1">
                {enemyPokemon.currentHp}/{enemyPokemon.stats.hp} HP
              </div>
              <div className="text-xs mt-1 space-y-0.5">
                <div>⚔️ {enemyAttackCount}/5</div>
                <div>🛡️ {enemyDefenseCount}/5</div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Battle Log */}
      <div className="absolute bottom-32 left-4 right-4 pointer-events-auto">
        {battleLog.length > 0 && (
          <Card className="bg-black bg-opacity-80 text-white">
            <CardContent className="p-3">
              <div className="max-h-24 overflow-y-auto">
                {battleLog.slice(-3).map((log, index) => (
                  <p key={index} className="text-sm mb-1">{log}</p>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Battle Progress and Instructions */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 pointer-events-auto">
        <Card className="bg-black bg-opacity-80 text-white mb-2">
          <CardContent className="p-2 text-center text-xs">
            <p>WASD/Arrows: Navigate • Enter/Space: Select • Esc: Cancel</p>
          </CardContent>
        </Card>
        {!canEndBattle && battlePhase === 'battle' && (
          <Card className="bg-yellow-600 text-black">
            <CardContent className="p-2 text-center text-xs">
              <p className="font-semibold">Battle must continue! Each Pokemon needs 5 attack + 5 defense moves</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
