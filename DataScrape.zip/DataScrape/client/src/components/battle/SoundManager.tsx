import { useEffect } from "react";
import { useAudio } from "../../lib/stores/useAudio";
import { useBattle } from "../../lib/stores/useBattle";

export function SoundManager() {
  const { setBackgroundMusic, setHitSound, setSuccessSound, isMuted } = useAudio();
  const { battlePhase } = useBattle();

  useEffect(() => {
    // Initialize audio elements
    const backgroundMusic = new Audio("/sounds/background.mp3");
    const hitSound = new Audio("/sounds/hit.mp3");
    const successSound = new Audio("/sounds/success.mp3");

    backgroundMusic.loop = true;
    backgroundMusic.volume = 0.3;

    setBackgroundMusic(backgroundMusic);
    setHitSound(hitSound);
    setSuccessSound(successSound);

    // Play background music when battle starts
    if (battlePhase === 'battle' && !isMuted) {
      backgroundMusic.play().catch(error => {
        console.log("Background music play prevented:", error);
      });
    }

    return () => {
      backgroundMusic.pause();
      backgroundMusic.currentTime = 0;
    };
  }, [battlePhase, isMuted]);

  return null;
}
