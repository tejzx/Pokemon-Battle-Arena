import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useTexture } from "@react-three/drei";
import { EnhancedPokemon } from "./EnhancedPokemon";
import { AttackEffects } from "./AttackEffects";
import { DynamicBackground } from "./DynamicBackground";
import { AICommentary } from "./AICommentary";
import { PokemonThemeMusic } from "./PokemonThemeMusic";
import { useBattle } from "../../lib/stores/useBattle";
import { useReplay } from "../../lib/stores/useReplay";
import * as THREE from "three";

export function BattleArena() {
  const arenaRef = useRef<THREE.Mesh>(null);
  const { playerPokemon, enemyPokemon, currentTurn, isAttacking, lastAttack } = useBattle();
  const { recordAction, isRecording } = useReplay();

  // Determine environment based on Pokemon types
  const environment = (() => {
    if (!playerPokemon && !enemyPokemon) return 'grass';
    
    const allTypes = [
      ...(playerPokemon?.types || []),
      ...(enemyPokemon?.types || [])
    ];
    
    if (allTypes.includes('fire')) return 'fire';
    if (allTypes.includes('water')) return 'water';
    if (allTypes.includes('electric')) return 'electric';
    if (allTypes.includes('psychic')) return 'psychic';
    if (allTypes.includes('rock') || allTypes.includes('ground')) return 'cave';
    return 'grass';
  })();
  
  // Use grass texture for the arena floor
  const grassTexture = useTexture("/textures/grass.png");
  grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
  grassTexture.repeat.set(8, 8);

  // Rotate arena slightly for animation
  useFrame((state) => {
    if (arenaRef.current) {
      arenaRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.1) * 0.02;
    }
  });

  return (
    <group>
      {/* Dynamic Background */}
      <DynamicBackground 
        environment={environment as any}
        weather={isAttacking ? 'storm' : 'sunny'}
      />

      {/* Arena floor */}
      <mesh ref={arenaRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial map={grassTexture} />
      </mesh>

      {/* Arena boundaries */}
      <mesh position={[0, 1, -10]} castShadow>
        <boxGeometry args={[20, 2, 0.5]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
      <mesh position={[0, 1, 10]} castShadow>
        <boxGeometry args={[20, 2, 0.5]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
      <mesh position={[-10, 1, 0]} castShadow>
        <boxGeometry args={[0.5, 2, 20]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
      <mesh position={[10, 1, 0]} castShadow>
        <boxGeometry args={[0.5, 2, 20]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>

      {/* Player Pokémon with enhanced animations */}
      {playerPokemon && (
        <EnhancedPokemon
          pokemonData={playerPokemon}
          position={[3, 0, 5]}
          isPlayer={true}
          isActive={currentTurn === 'player'}
        />
      )}

      {/* Enemy Pokémon with enhanced animations */}
      {enemyPokemon && (
        <EnhancedPokemon
          pokemonData={enemyPokemon}
          position={[-3, 0, -5]}
          isPlayer={false}
          isActive={currentTurn === 'enemy'}
        />
      )}

      {/* AI Commentary */}
      <AICommentary />
      
      {/* Pokemon Theme Music */}
      <PokemonThemeMusic />

      {/* Attack Effects */}
      {isAttacking && <AttackEffects />}
    </group>
  );
}
